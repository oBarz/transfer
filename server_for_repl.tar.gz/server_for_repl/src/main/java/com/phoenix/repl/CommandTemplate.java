package com.phoenix.repl;

import java.util.List;

public final class CommandTemplate {
    private String name;
    private String description;
    private String resultType;
    private List<Parameter> parameterList;
    static final class Parameter{
        private String name;
        private String description;
        private String type;
        private boolean required;
        Parameter(String name, String description, String type, boolean required){
            this.name = name;
            this.description = description;
            this.type = type;
            this.required = required;
        }
    }
    CommandTemplate(String name, String description, String resultType, List<Parameter> parameterList){
        this.name = name;
        this.description = description;
        this.resultType = resultType;
        this.parameterList = parameterList;
    }
    String getCommandTemplateAsJsonString(){

        StringBuilder parameters = new StringBuilder();
        if(parameterList != null && parameterList.size() >= 1){
                parameters.append("[ ");
                for(Parameter p : parameterList){
                    parameters.append("\n{\n");
                    parameters.append(Constants.name +": \""+p.name+"\", \n");
                    parameters.append(Constants.description +": \""+p.description+"\", \n");
                    parameters.append(Constants.type +": \""+p.type+"\", \n");
                    parameters.append(Constants.required +": \""+p.required+"\" \n");
                    parameters.append("},");
                }
                parameters.setLength(parameters.length() - 1);
                parameters.append("\n]");
        }
        return parameters.length() >= 1 ? "{\n" +
                Constants.name + ":\""+name+"\",\n" +
                Constants.description + ":\""+description+"\",\n" +
                Constants.type + ":\""+resultType+"\",\n" +
                Constants.parameters+ ":"+parameters.toString()+"\n"
                +"}" :
                "{\n" +
                        Constants.name + ":\""+name+"\",\n" +
                        Constants.description + ":\""+description+"\",\n" +
                        Constants.type + ":\""+resultType+"\"\n"
                 +"}";
    }
}
