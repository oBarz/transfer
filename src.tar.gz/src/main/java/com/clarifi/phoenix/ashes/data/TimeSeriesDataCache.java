package com.clarifi.phoenix.ashes.data;

import com.clarifi.phoenix.ashes.common.Common;
import com.clarifi.phoenix.ashes.data.TimeSeriesData;
import com.clarifi.phoenix.ashes.data.TimeSeriesDataKey;
import org.apache.ignite.cache.*;
import org.apache.ignite.configuration.CacheConfiguration;

public class TimeSeriesDataCache {

  public static CacheConfiguration<TimeSeriesDataKey, TimeSeriesData> timeSeriesDataCacheConfiguration()
  {
    CacheConfiguration<TimeSeriesDataKey, TimeSeriesData> cacheCfg = new CacheConfiguration(Common.TIMESERIES_DATA_CACHE);

    cacheCfg.setCacheMode(CacheMode.PARTITIONED);
    cacheCfg.setBackups(2);
    cacheCfg.setRebalanceMode(CacheRebalanceMode.SYNC);
    //cacheCfg.setWriteSynchronizationMode(CacheWriteSynchronizationMode.FULL_SYNC);
    cacheCfg.setPartitionLossPolicy(PartitionLossPolicy.READ_ONLY_SAFE);

    return cacheCfg;
  }

  public static long createKey(int issueId, int dataItemId) {
    long i1 = ((long) issueId) << 32;
    long i2 = dataItemId;
    long result = i1 | i2;
    return result;
  }

  public static int generateDataItemId(int di) {
    return 1000 + di;
  }
  public static int generateDerivedDataItemId(int di) {
    return 100000 + di;
  }

  public static int generateIssueId(int i) {
    return 1000000 + i;
  }


}
