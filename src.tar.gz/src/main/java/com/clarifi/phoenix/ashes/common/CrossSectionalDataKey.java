package com.clarifi.phoenix.ashes.common;

import org.apache.ignite.cache.affinity.AffinityKeyMapped;

public class CrossSectionalDataKey {
    public final int issueId;
    @AffinityKeyMapped
    public final char date;

    public CrossSectionalDataKey(final int issueId, final char date) {
        this.issueId = issueId;
        this.date = date;
    }
}
