package com.clarifi.phoenix.ashes.common;

/**
 * This exception represents that the User cancelled an operation.
 * <p>
 * Example: File chooser dialog is cancelled.
 *
 * @author mmorton
 */
public class UserCancelledException extends RuntimeException
{
  /**
   * Constructor that takes in the exception message as a String
   *
   * @param message exception message
   */
  public UserCancelledException( String message )
  {
    super( message );
  }

  /**
   * Constructor that takes in the exception message as a String and a Throwable
   * to nest
   *
   * @param message exception message
   * @param cause the Throwable to nest
   */
  public UserCancelledException( String message, Throwable cause )
  {
    super( message, cause );
  }
}
