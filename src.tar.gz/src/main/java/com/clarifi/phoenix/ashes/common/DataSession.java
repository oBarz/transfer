package com.clarifi.phoenix.ashes.common;


import java.time.Instant;
import java.util.UUID;

public interface DataSession {
    UUID getId();
    UUID getUserId();
    Status getStatus();

    PhoenixDateRange getRange();
    int[] getIssues();
    int[] getDataItems();

    Instant getLastAccessedAt();
    void updateLastAccessedAt();

    enum Status {
        Initializing,
        Failed,
        Available
    }
}
