package com.clarifi.phoenix.ashes.common;

import com.clarifi.phoenix.ashes.data.TimeSeriesDataKey;

import java.util.ArrayList;
import java.util.List;

public class DataItemRangeAccumulator {
  private final int issueId;
  public final List<int[]> dataItemRanges;
  public int[] currentRange = new int[2];

  public DataItemRangeAccumulator(TimeSeriesDataKey key) {
    this.issueId = key.issueId;
    dataItemRanges = new ArrayList<>();
    currentRange[0] = key.dataItemId;
    currentRange[1] = key.dataItemId;
  }

  public void add(TimeSeriesDataKey key) {
    if (key.issueId != issueId) {
      throw new IllegalArgumentException("issueId = " + key.issueId + " does not match local issueid = " + issueId);
    }

    if (key.dataItemId == currentRange[1] + 1) {
      currentRange[1] = key.dataItemId;
    } else {
      dataItemRanges.add(currentRange);
      currentRange = new int[2];
      currentRange[0] = key.dataItemId;
      currentRange[1] = key.dataItemId;
    }
  }

  @Override
  public String toString() {
    String result = "issueId = " + issueId + ": ";
    boolean needComma = false;
    for (int[] range : dataItemRanges) {
      if (needComma) {
        result += ", ";
      }
      result += "[" + range[0] + ", " + range[1] + "]";
      needComma = true;
    }
    if (needComma) {
      result += ", ";
    }
    result += "[" + currentRange[0] + ", " + currentRange[1] + "]";
    return result;
  }
}
