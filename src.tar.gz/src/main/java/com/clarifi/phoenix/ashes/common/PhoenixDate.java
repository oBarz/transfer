package com.clarifi.phoenix.ashes.common;

import java.lang.ref.WeakReference;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.function.Supplier;

public class PhoenixDate {
    public static PhoenixDate MIN = new PhoenixDate(Character.MIN_VALUE);
    public static PhoenixDate MAX = new PhoenixDate(Character.MAX_VALUE);

    private static final ThreadLocal<LocalDate> EPOCH = ThreadLocal.withInitial(new Supplier<LocalDate>() {
        @Override
        public LocalDate get() {
            return LocalDate.EPOCH;
        }
    });

    private char packed;
    private WeakReference<LocalDate> unpacked;

    public PhoenixDate(final char value) {
        this.packed = (char) value;
    }

    public int getYear() {
        final LocalDate date = unpack();
        return date.getYear();
    }

    public int getMonth() {
        final LocalDate date = unpack();
        return date.getMonthValue();
    }

    public int getDayOfMonth() {
        final LocalDate date = unpack();
        return date.getDayOfMonth();
    }

    public char getPackedValue() {
        return packed;
    }

    public PhoenixDate plusDays(final int amount) {
        final char value = (char) (packed + (char) (amount & 0xFFFF));
        return PhoenixDate.fromPackedValue(value);
//        final LocalDate date = unpack();
//        return PhoenixDate.fromLocalDate(date.plusDays(amount));
    }

    //-- There is no need to synchronize this if we go for speed vs memory efficiency;
    // it will re-compute and re-assign if called from multiple threads without side effects.
    private LocalDate unpack() {
        if (unpacked != null) {
            final LocalDate reference = unpacked.get();
            if (reference != null) {
                return reference;
            }
        }

        final LocalDate date = EPOCH.get().plusDays(packed);
        unpacked = new WeakReference<>(date);

        return date;
    }

    public static PhoenixDate fromLocalDate(final LocalDate date) {
        final long daysBetween = ChronoUnit.DAYS.between(EPOCH.get(), date);

        return new PhoenixDate((char) daysBetween);
    }

    public static PhoenixDate of(final int year, final int month, final int day) {
        return fromLocalDate(LocalDate.of(year, month, day));
    }

    public static PhoenixDate fromPackedValue(final char value) {
        return new PhoenixDate(value);
    }

    @Override
    public String toString() {
        return unpack().toString();
    }
}
