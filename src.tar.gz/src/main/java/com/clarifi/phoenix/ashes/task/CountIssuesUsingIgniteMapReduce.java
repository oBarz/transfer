package com.clarifi.phoenix.ashes.task;

import com.clarifi.phoenix.ashes.common.PackedDataSession;
import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteCache;
import org.apache.ignite.IgniteException;
import org.apache.ignite.cache.CachePeekMode;
import org.apache.ignite.cluster.ClusterNode;
import org.apache.ignite.compute.ComputeJob;
import org.apache.ignite.compute.ComputeJobAdapter;
import org.apache.ignite.compute.ComputeJobResult;
import org.apache.ignite.compute.ComputeTaskAdapter;
import org.apache.ignite.resources.IgniteInstanceResource;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.*;

import static com.clarifi.phoenix.ashes.server.ServerApp.PREFIX_CACHE_USER_DATA_SESSIONS;

public class CountIssuesUsingIgniteMapReduce extends ComputeTaskAdapter<List<UUID>, Integer> {
    private final UUID userId;

    private double step;

    @IgniteInstanceResource
    Ignite ignite;

    public CountIssuesUsingIgniteMapReduce(final UUID userId) {
        this.userId = userId;
    }

    @Override
    public @NotNull Map<? extends ComputeJob, ClusterNode> map(
            final List<ClusterNode> list,
            final @Nullable List<UUID> sessions) throws IgniteException {
        final Map<ComputeJob, ClusterNode> map = new HashMap<>();

        final String cacheName = String.format("%s:%s", PREFIX_CACHE_USER_DATA_SESSIONS, userId.toString());
        final IgniteCache<UUID, PackedDataSession> userSessions = ignite.cache(cacheName);

        step = 1d / userSessions.size(CachePeekMode.ALL);

        Iterator<ClusterNode> iterator = list.iterator();
        for (final UUID id: sessions) {
            if (!iterator.hasNext()) {
                iterator = list.iterator();
            }

            final ClusterNode node = iterator.next();

            map.put(new ComputeJobAdapter() {
                @Override
                public Object execute() throws IgniteException {
                    //-- Update session last access timestamp
                    final PackedDataSession session = userSessions.get(id);
                    session.updateLastAccessedAt();

                    userSessions.put(session.getId(), session);

                    final int[] issues = session.getIssues();
                    if (issues == null) {
                        return Integer.valueOf(0);
                    }

                    return Integer.valueOf(issues.length);
                }
            }, node);
        }

        step = 1d / map.size();

        return map;
    }

    @Override
    public @Nullable Integer reduce(final List<ComputeJobResult> list) throws IgniteException {
        int total = 0;

        for (final ComputeJobResult result: list) {
            final Integer value = result.<Integer>getData();
            total += value.intValue();
        }

        return Integer.valueOf(total);
    }
}
