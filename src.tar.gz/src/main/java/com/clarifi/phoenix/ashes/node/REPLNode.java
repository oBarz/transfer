package com.clarifi.phoenix.ashes.node;

import com.clarifi.phoenix.ashes.common.Common;
import com.clarifi.phoenix.ashes.common.Stoppable;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteCache;
import org.apache.ignite.IgniteException;
import org.apache.ignite.Ignition;
import org.apache.ignite.configuration.IgniteConfiguration;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.reflect.Method;

/**
 * A Node with basic command processing
 */
public class REPLNode extends BaseNode {
//  private static final Logger LOG = LogManager.getLogger(com.clarifi.phoenix.ashes.node.REPLNode.class);
  private static Log LOG = LogFactory.getLog(BaseNode.class);
  private CommandDispatcher _commandDispatcher;

  /**
   * Main Method. Simply call the Client's main method,
   * passing in our class.
   * @param args the command line arguments
   */
  public static void main(String[] args)
  {
    //ABSOLUTELY NO extra code should go here.  If you think you need to
    //  add code to this method talk to Glav first.
    try
    {
      BaseNode.nodeMain(args, REPLNode.class);
    }
    catch (Throwable t)
    {
      displayFatalErrorMessage(t);
      exit(-1);
    }
  }

  /* This code will go to Ignite-specific implementation classes */
  public static void main2(String[] args) throws IgniteException
  {
//    IgniteConfiguration cfg = com.clarifi.phoenix.ashes.common.Common.igniteClientConfiguration();
    IgniteConfiguration cfg = Common.ignitePersistentServerConfiguration();

    // Starting the node
    Ignite ignite = Ignition.start(cfg);


    // Disconnect from the cluster.
//    ignite.close();
  }

  private static void loadIntToStringValues( Ignite ignite, String cacheName, int numValues)
  {
    // Create an IgniteCache and put some values in it.
    IgniteCache<Integer, String> cache = ignite.getOrCreateCache(cacheName);

    for (int i = 0; i < numValues; ++i){
      cache.put(i, "Issue Name " + i);
    }

    System.out.println(">> Created the cache '" + cacheName + "' and added the values.");
  }

  @Override
  public String getNodeDescription() {
    return "REPL Node";
  }

  @Override
  protected void initNode() {
    Stoppable commandProcessorStopper = new Stoppable();

    //start the Command Dispatcher
    _commandDispatcher = new CommandDispatcher(commandProcessorStopper);

  }

  @Override
  protected void doShutdown() {

    LOG.info("Shutting down command dispatcher");
    _commandDispatcher.shutdown();

  }

  /**
   * Display the fatal error that occured
   * @param t the throwable that was thrown
   */
  private final static void displayFatalErrorMessage(Throwable t)
  {
    try
    {
      //send it to err first thing
      t.printStackTrace(System.err);

      //do this with Reflection since we do not want to load
      //Swing Components unless we have to
      Class dlgClass       = Class.forName("javax.swing.JOptionPane");
      Class componentClass = Class.forName("java.awt.Component");
      Method msgDlg        = dlgClass.getMethod("showMessageDialog",
        new Class[]{ componentClass,
          Object.class,
          String.class,
          Integer.TYPE });
      String linSep = System.getProperty("line.separator");
      String msg = "Fatal Error in Data Cache Server!" +
        linSep + linSep + t.getMessage();

      msgDlg.invoke(null, new Object[]{ null, msg, "Fatal Error!",
        Integer.valueOf(dlgClass.getField("ERROR_MESSAGE").getInt(null))});
    }
    catch (Throwable tt) {/** ignore */ }
  }

  private class CommandDispatcher extends Thread
  {
    private Log LOG = LogFactory.getLog(BaseNode.class);

    private final Stoppable _connStopper;
    private volatile boolean _alive = true;

    private CommandDispatcher(Stoppable connStopper)
    {
      super("com.clarifi.phoenix.ashes.node.REPLNode.CommandDispatcher");
      setDaemon(true);

      _connStopper = connStopper;
      start();
    }

    private abstract class Command {
      protected int initState;
      private final BufferedReader sysInReader;

      private Command(int state, BufferedReader sysInRead) {
        sysInReader = sysInRead;
        initState = state;
      }

      private final boolean invoke() {
        synchronized (CommandDispatcher.this) {
          return doInvoke();
        }
      }

      abstract protected boolean doInvoke();
    }

    private class QuitCommand extends Command
    {
      private QuitCommand(int state)
      {
        super(state, null);
      }

      @Override
      protected final boolean doInvoke()
      {
        return attemptToSignalClientExit();
      }
    }

    private class GCCommand extends Command
    {
      private GCCommand(int state)
      {
        super(state, null);
      }

      @Override
      protected final boolean doInvoke()
      {
        displayMsg("GC Command called");

        return false;
      }
    }


    private boolean dispatchCommand(String command, BufferedReader sysInReader)
    {
        //do this check only if initialized
        if (command.length() == 0)
        {
          //just output instructions
          outputInstructions();
          return false;
        }

        Command comm = null;
        if (command.equals("q"))
        {
          comm = new QuitCommand(0);
        }
        else if (command.equals("gc"))
        {
          comm = new GCCommand(0);
        }
        else
          displayMsg("Unknown command \'"+command+"\'");

        if (comm != null)
          return comm.invoke();
        else
          return false;
    }

    private void shutdown()
    {
      _alive = false;
      try {Thread.sleep(500);} catch (Exception ex) {/** Ignore */}
    }

    @Override
    public final void run()
    {

      String command = null;
      BufferedReader sysInReader = new BufferedReader(new InputStreamReader(System.in));

      while(_alive)
      {
        try
        {
          if (sysInReader.ready())
          {
            //block till input
            command = new String(sysInReader.readLine().toLowerCase().trim());

            //dispatch it
            boolean shutDown = dispatchCommand(command, sysInReader);
            if (shutDown)
              _alive = false;
          }
          else
          {
            //sleep until ready
            try {sleep(250);} catch (Exception ex) {/** Ignore */}
          }
        }
        catch (Throwable t)
        {
          LOG.warn("Error in DataCacheServer.ExitListener safeRun()", t);
        }
      }
    }
  }

  private void outputInstructions()
  {
    boolean asService = isRunningAsAService();

    if (!asService) System.out.println();
    if (!asService) System.out.println();

    if (asService)
      return; //don;t drop commands if running as a service

    System.out.println(" Enter \'q\'    to quit.");
    System.out.println(" Enter \'gc\'   to attempt Java memory Garbage Collection.");

    System.out.print(  " >");
  }

  private boolean isRunningAsAService() {
    return false;
  }

}
