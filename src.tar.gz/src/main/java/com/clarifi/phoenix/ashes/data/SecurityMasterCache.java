package com.clarifi.phoenix.ashes.data;

import com.clarifi.phoenix.ashes.common.Common;
import com.clarifi.phoenix.ashes.data.IssueData;
import org.apache.ignite.cache.CacheMode;
import org.apache.ignite.configuration.CacheConfiguration;

public class SecurityMasterCache {

  public static CacheConfiguration<Integer, IssueData> configuration()
  {
    CacheConfiguration<Integer, IssueData> cacheCfg = new CacheConfiguration(Common.SECURITY_MASTER_CACHE);
    cacheCfg.setCacheMode(CacheMode.REPLICATED);

    return cacheCfg;
  }

}
