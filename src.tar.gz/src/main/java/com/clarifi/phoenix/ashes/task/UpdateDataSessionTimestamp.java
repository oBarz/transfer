package com.clarifi.phoenix.ashes.task;

import com.clarifi.phoenix.ashes.common.DataSession;
import com.clarifi.phoenix.ashes.common.PackedDataSession;
import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteCache;
import org.apache.ignite.lang.IgniteRunnable;
import org.apache.ignite.resources.IgniteInstanceResource;

import java.util.UUID;

import static com.clarifi.phoenix.ashes.server.ServerApp.PREFIX_CACHE_USER_DATA_SESSIONS;

public class UpdateDataSessionTimestamp implements IgniteRunnable {
    @IgniteInstanceResource
    Ignite ignite;

    private final String userId;
    private final String sessionId;

    public UpdateDataSessionTimestamp(final String userId, final String sessionId) {
        this.userId = userId;
        this.sessionId = sessionId;
    }

    @Override
    public void run() {
        final String cacheName = String.format("%s:%s", PREFIX_CACHE_USER_DATA_SESSIONS, userId.toString());
        final IgniteCache<UUID, PackedDataSession> cache = ignite.cache(cacheName);
        final UUID uid = UUID.fromString(this.sessionId);
        final DataSession session = cache.get(uid);

        if (session != null) {
            session.updateLastAccessedAt();

            System.out.printf("Session %s had it's last access timestamp updated\n", session);
        }
    }
}
