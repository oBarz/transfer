package com.clarifi.phoenix.ashes.server;

import com.clarifi.phoenix.ashes.task.CountDataSessionIssues;
import io.undertow.server.HttpHandler;
import io.undertow.server.HttpServerExchange;
import io.undertow.util.PathTemplateMatch;
import io.undertow.util.StatusCodes;
import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteCompute;
import org.apache.ignite.IgniteException;
import org.apache.ignite.lang.IgniteFuture;

import java.util.Deque;
import java.util.Map;
import java.util.concurrent.*;

public class DataSessionCountIssuesHandler implements HttpHandler {
    private static final long DEFAULT_TIMEOUT_S = 2L;

    private final ServerApp server;
    private boolean useTL;
    private long timeoutS;

    public DataSessionCountIssuesHandler(final ServerApp server) {
        this.server = server;

        timeoutS = DEFAULT_TIMEOUT_S;
        useTL = true;
    }

    @Override
    public void handleRequest(final HttpServerExchange exchange) {
        //-- UserId is in the path (REST request)
        PathTemplateMatch pathMatch = exchange.getAttachment(PathTemplateMatch.ATTACHMENT_KEY);
        String userId = pathMatch.getParameters().get("userId");

        handleParams(exchange);

        final Ignite ignite = server.getIgnite();

        final ExecutorService executor = server.getExecutor();
        exchange.dispatch(executor, new Runnable() {
            @Override
            public void run() {
                final IgniteCompute compute = ignite.compute();

                final CountDataSessionIssues delegate = new CountDataSessionIssues(
                    userId,
                    useTL
                );

                final IgniteFuture<Integer> future = compute.callAsync(delegate);

                try {
                    final Integer count = future.get(timeoutS, TimeUnit.SECONDS);

                    exchange.setStatusCode(StatusCodes.OK);
                    exchange.getResponseSender().send(String.format("Number of issues: %d", count.intValue()));

                    System.out.printf(
                        "{Thread:%s} Issues in user's '%s' data sessions: %d.\n",
                        Thread.currentThread().getName(),
                        userId,
                        count
                    );
                } catch (final IgniteException ex) {
                    if (!future.isCancelled() && !future.isDone()) {
                        sendSessionStatus(exchange);
                    } else {
                        exchange.setStatusCode(StatusCodes.INTERNAL_SERVER_ERROR);
                        exchange.getResponseSender().send("Unexpected error while processing request");
                    }
                } catch (final Throwable err) {
                    err.printStackTrace(System.err);

                    exchange.setStatusCode(StatusCodes.INTERNAL_SERVER_ERROR);
                    exchange.getResponseSender().send("Unexpected error while processing request");
                } finally {
                    exchange.endExchange();
                }
            }
        });
    }

    private void handleParams(final HttpServerExchange exchange) {
        final Map<String, Deque<String>> params = exchange.getQueryParameters();
        if (params == null || params.isEmpty()) {
            return;
        }

        final Deque<String> timeout = exchange.getQueryParameters().get("timeout");
        if (timeout != null && !timeout.isEmpty()) {
            timeoutS = Integer.parseInt(timeout.getFirst());
        }

        final Deque<String> useTL = exchange.getQueryParameters().get("useTL");
        if (useTL != null && !useTL.isEmpty()) {
            this.useTL = "yes".equalsIgnoreCase(useTL.getFirst());
        }
    }

    private void sendSessionStatus(final HttpServerExchange exchange) {
        exchange.setStatusCode(StatusCodes.CONTINUE);

        // todo: replace with actual job id and completion percentage
        exchange.getResponseSender().send("The task is taking longer than usual, please check again shortly");
    }
}
