package com.clarifi.phoenix.ashes.client;

import com.amazon.ion.*;
import com.amazon.ion.system.IonSystemBuilder;
import com.clarifi.common.application.App;
import com.clarifi.common.util.Logging;
import com.clarifi.phoenix.ashes.common.*;
import io.undertow.util.StatusCodes;
import org.apache.logging.log4j.Logger;

import java.io.*;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.time.Instant;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

public class ClientApp {

    private static final Logger _logger = Logging.getLogger(ClientApp.class);
    private final String host;
    private final int port;
    private final IonSystem ion;

    private HttpClient httpClient;

    public ClientApp(final String host, final int port) {
        this.host = host;
        this.port = port;

        httpClient = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(5L))
                .version(HttpClient.Version.HTTP_2)
                .followRedirects(HttpClient.Redirect.ALWAYS)
                .build();

        ion = IonSystemBuilder.standard().build();
    }

    private HttpRequest.Builder request(final String path, final Map<String, String> params) {
        final URLBuilder builder = new URLBuilder();
        builder.http().host(host).port(port).path("api2", path);
        builder.addQueryParameters(params);

        return HttpRequest.newBuilder()
                .version(HttpClient.Version.HTTP_2)
                .uri(builder.build())
                .timeout(Duration.ofSeconds(5L));
    }

    private DataSession parseDataSession(final InputStream stream) throws IOException {
        final PackedDataSession.Reader reader = new PackedDataSession.IonReader();

        return reader.read(stream.readAllBytes());
    }

    public PhoenixUser authenticate(final String userName, String password) {
        // todo: implement

        String token = AuthenticationService.getToken(userName,"Phoenix@1234");
        return new PhoenixUser(userName,token);
    }

    private void writeDataSession(final PhoenixUser user,
                                  final PhoenixDateRange range,
                                  final int[] dataItems,
                                  final int[] issues,
                                  final OutputStream stream) {
        final IonStruct params = ion.newEmptyStruct();
        params.add("user", ion.newString(user.getId().toString()));
        params.add("range", PhoenixDateRange.toIon(range, ion));
        params.add("dataItems", ion.newList(dataItems));
        params.add("issues", ion.newList(issues));
        params.add("lastAccessedAt", ion.newInt(Instant.now().toEpochMilli()));

        final IonWriter writer = ion.newTextWriter(stream);
        try {
            params.writeTo(writer);

            writer.flush();
            writer.close();

            stream.flush();
        } catch (final Throwable err) {
            // todo: log error
            err.printStackTrace(System.err);
        }
    }

    public DataSession createSmallDataSession(final PhoenixUser user, final PhoenixDateRange range,
                                              final int[] dataItems, final int[] issues) {
         try {
            final HttpRequest.Builder builder = request("data-session/new", null);
            if (user.hasOktaToken()) {
                builder.header("Token", user.getOktaToken());
            }

            final ByteArrayOutputStream stream = new ByteArrayOutputStream();
            writeDataSession(user, range, dataItems, issues, stream);
            builder.PUT(HttpRequest.BodyPublishers.ofByteArray(stream.toByteArray()));

            final HttpRequest request = builder.build();
            final HttpResponse<InputStream> response = httpClient.send(
                    request, HttpResponse.BodyHandlers.ofInputStream());

            // todo: handle other response codes
            if (response.statusCode() == StatusCodes.OK) {
                return parseDataSession(response.body());
            }
        } catch (final Throwable err) {
            // todo: log error
            err.printStackTrace(System.err);
        }

        return null;
    }

    public DataSession createLargeDataSession(final PhoenixUser user, final PhoenixDateRange range) {
        final int[] dataItems = new int[8];
        for (int idx = 0; idx < dataItems.length; idx++) {
            dataItems[idx] = 100 + idx;
        }

        final int[] issues = new int[24000];
        for (int idx = 0; idx < issues.length; idx++) {
            issues[idx] = 1000 + idx;
        }

        try {
            final Map<String, String> params = new HashMap<>();
            params.put("timeout", Integer.toString(30));

            final HttpRequest.Builder builder = request("data-session/new", params);
            builder.header("Content-Encoding", "gzip");
            builder.header("Accept-Encoding", "gzip");

            if (user.hasOktaToken()) {
                builder.header("Phoenix-Auth-Token", user.getOktaToken());
            }

            final ByteArrayOutputStream stream = new ByteArrayOutputStream();
            writeDataSession(user, range, dataItems, issues, new GZIPOutputStream(stream));
            builder.POST(HttpRequest.BodyPublishers.ofByteArray(stream.toByteArray()));

            builder.timeout(Duration.ofSeconds(35L));
            final HttpRequest request = builder.build();

            final HttpResponse<InputStream> response = httpClient.send(
                    request, HttpResponse.BodyHandlers.ofInputStream());

            // todo: handle other response codes
            if (response.statusCode() == StatusCodes.OK) {
                final List<String> encodings = response.headers().allValues("Content-Encoding");
                if (encodings.contains("gzip")) {
                    return parseDataSession(new GZIPInputStream(response.body()));
                } else {
                    return parseDataSession(response.body());
                }
            } else if (response.statusCode() == StatusCodes.REQUEST_TIME_OUT) {
                System.out.println(new String(response.body().readAllBytes()));
            }
        } catch (final Throwable err) {
            // todo: log error
            err.printStackTrace(System.err);
        }

        return null;
    }

    public DataSession getDataSession(final UUID id, final PhoenixUser user) {
        final HttpRequest request;
        try {
            final Map<String, String> params = new HashMap<>();
            params.put("userId", user.getId().toString());

            // todo: replace with path builder factory
            final String path = String.format("data-session/get/%s", id.toString());

            final HttpRequest.Builder builder = request(path, params);
            builder.header("Accept-Encoding", "gzip");

            if (user.hasOktaToken()) {
                builder.header("Phoenix-Auth-Token", user.getOktaToken());
            }

            builder.GET();

            request = builder.build();
        } catch (final Throwable err) {
            // todo: log error

            err.printStackTrace(System.err);

            return null;
        }

        final HttpResponse<InputStream> response;
        try {
            response = httpClient.send(request, HttpResponse.BodyHandlers.ofInputStream());
        } catch (final Throwable err) {
            // todo: log error
            err.printStackTrace(System.err);

            return null;
        }

        // todo: handle other response codes
        if (response.statusCode() == StatusCodes.OK) {
            try {
                return parseDataSession(response.body());
            } catch (final Throwable err) {
                err.printStackTrace(System.err);
            }
        }

        return null;
    }

    public void dumpDataSessionsIssueCount(final PhoenixUser user, final boolean useTL) {
        final HttpRequest request;
        try {
            final Map<String, String> params = new HashMap<>();
            params.put("useTL", useTL ? "yes" : "no");

            // todo: replace with path builder factory
            final String path = String.format("data-sessions/count-issues/%s", user.getId().toString());

            final HttpRequest.Builder builder = request(path, params);
            builder.timeout(Duration.ofSeconds(30L));

            if (user.hasOktaToken()) {
                builder.header("Phoenix-Auth-Token", user.getOktaToken());
            }

            builder.GET();

            request = builder.build();
        } catch (final Throwable err) {
            // todo: log error

            err.printStackTrace(System.err);
            return;
        }

        final HttpResponse<InputStream> response;
        try {
            response = httpClient.send(request, HttpResponse.BodyHandlers.ofInputStream());
        } catch (final Throwable err) {
            // todo: log error
            err.printStackTrace(System.err);
            return;
        }

        // todo: handle other response codes
        if (response.statusCode() == StatusCodes.OK) {
            try {
                System.out.println(new String(response.body().readAllBytes()));
            } catch (final IOException io) {
                io.printStackTrace(System.err);
            }
        }
    }

    public void dumpTimeSeries(final int issueId, final int dataItemId, final PhoenixDate date) {
        final HttpRequest request;
        try {
            // todo: replace with path builder factory
            final String path = String.format(
                    "time-series/%d/%d-%02d-%02d/%d",
                    issueId,
                    date.getYear(),
                    date.getMonth(),
                    date.getDayOfMonth(),
                    dataItemId
            );

            final HttpRequest.Builder builder = request(path, null);
            builder.timeout(Duration.ofSeconds(30L));

            builder.GET();

            request = builder.build();
        } catch (final Throwable err) {
            // todo: log error

            err.printStackTrace(System.err);
            return;
        }

        final HttpResponse<InputStream> response;
        try {
            response = httpClient.send(request, HttpResponse.BodyHandlers.ofInputStream());
        } catch (final Throwable err) {
            // todo: log error
            err.printStackTrace(System.err);
            return;
        }

        // todo: handle other response codes
        if (response.statusCode() == StatusCodes.OK) {
            try {
                System.out.println(new String(response.body().readAllBytes()));
            } catch (final IOException io) {
                io.printStackTrace(System.err);
            }
        }
    }

    public static void main(final String[] args) throws Throwable {
        App.initBeforeAnythingElse(args, 0, "Client App", "1.0.0");

        final ClientApp client = new ClientApp("localhost", 8081);

        App.appMain(client::startup, client::shutdown);
    }

    private void startup() {
        final PhoenixUser user = this.authenticate("harsh.vardhan@spglobal.com","Phoenix@1234");

        final DataSession small = this.createSmallDataSession(
                user,
                PhoenixDateRange.startsIn(2024, 1, 1).withEnd(2024, 12, 31),
                new int[] { 101, 102 },
                new int[] { 1001, 1002, 1003 }
        );

        System.out.println(small);

        final DataSession copy = this.getDataSession(small.getId(), user);
        // todo: deep compare session vs. copy
        System.out.println(copy);

        final DataSession large = this.createLargeDataSession(
                user,
                PhoenixDateRange.startsIn(2023, 1, 1).withEnd(2023, 2, 1)
        );

        System.out.println(large);

        this.dumpDataSessionsIssueCount(user, false);
        this.dumpDataSessionsIssueCount(user, true);

        this.dumpTimeSeries(1001, 101, PhoenixDate.of(2024, 1, 11));
        this.dumpTimeSeries(1002, 102, PhoenixDate.of(2024, 1, 10));
        this.dumpTimeSeries(1003, 103, PhoenixDate.of(2023, 1, 9));
    }

    private void shutdown() {
        try {
            //httpClient.close();
        } catch (Exception e) {
            _logger.error("Error closing HTTP client: " + e.getMessage());
        } finally {
            httpClient = null;

            // todo: needed for closing of the httpclient
            System.gc();
        }
    }
}
