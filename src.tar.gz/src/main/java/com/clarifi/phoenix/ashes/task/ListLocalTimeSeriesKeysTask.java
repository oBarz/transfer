package com.clarifi.phoenix.ashes.task;

import com.clarifi.phoenix.ashes.common.Common;
import com.clarifi.phoenix.ashes.common.DataItemRangeAccumulator;
import com.clarifi.phoenix.ashes.common.IssueRangeAccumulator;
import com.clarifi.phoenix.ashes.data.TimeSeriesData;
import com.clarifi.phoenix.ashes.data.TimeSeriesDataKey;
import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteCache;
import org.apache.ignite.cache.CachePeekMode;
import org.apache.ignite.lang.IgniteRunnable;
import org.apache.ignite.resources.IgniteInstanceResource;

import javax.cache.Cache;
import java.util.*;

/**
 * A computation tasks that prints out a node ID and some details about its OS and JRE.
 * Plus, the code shows how to access data stored in a cache from the computation task.
 */
class ListLocalTimeSeriesKeysTask implements IgniteRunnable {
  @IgniteInstanceResource
  Ignite ignite;

  @Override
  public void run() {
    System.out.println(">> Executing the ListLocalKeysTask7 task");

    System.out.println("\tNode ID: " + ignite.cluster().localNode().id());

    IgniteCache<TimeSeriesDataKey, TimeSeriesData> cache = ignite.cache(Common.TIMESERIES_DATA_CACHE);

    long numPrimaryEntries = cache.localSizeLong(CachePeekMode.PRIMARY);
    long numBackupEntries = cache.localSizeLong(CachePeekMode.BACKUP);

    System.out.println("\tPRIMARY: " + numPrimaryEntries + " entries");
    System.out.println("\tBACKUP: " + numBackupEntries + " entries");

    System.out.println(">> List local keys for " + Common.TIMESERIES_DATA_CACHE + " PRIMARY cache:");

    Iterable<Cache.Entry<TimeSeriesDataKey, TimeSeriesData>> es = cache.localEntries(CachePeekMode.PRIMARY);
    Iterator<Cache.Entry<TimeSeriesDataKey, TimeSeriesData>> it = es.iterator();
    Map<Integer, DataItemRangeAccumulator> issueRanges = new HashMap<>();
    while (it.hasNext()) {
      TimeSeriesDataKey key = it.next().getKey();
      DataItemRangeAccumulator range = issueRanges.get(key.issueId);
      if (range == null) {
        range = new DataItemRangeAccumulator(key);
        issueRanges.put(key.issueId, range);
      } else {
        range.add(key);
      }
    }

    System.out.println("\tissueRanges.size() =  " + issueRanges.size());
    int i = 0;
    List<Integer> issueIds = new ArrayList<>(issueRanges.size());
    Iterator<Map.Entry<Integer, DataItemRangeAccumulator>> it2 = issueRanges.entrySet().iterator();
    while (it2.hasNext()) {
      Map.Entry<Integer, DataItemRangeAccumulator> kv = it2.next();
      int issueId = kv.getKey();
      issueIds.add(issueId);
    }
    Collections.sort(issueIds);

    IssueRangeAccumulator consolidatedIssues = new IssueRangeAccumulator();
    for (int issueId : issueIds) {
      DataItemRangeAccumulator acc = issueRanges.get(issueId);
      if (acc.dataItemRanges.isEmpty()) {
        consolidatedIssues.add(issueId);
      } else {
        System.out.println("\t\tpartial issueId =  " + issueId);
      }
    }

    for (int[] range : consolidatedIssues.ranges) {
      System.out.println("\t\t[" + range[0] + " .. " + range[1] + "]");
    }
    int[] range = consolidatedIssues.currentRange;
    System.out.println("\t\t[" + range[0] + " .. " + range[1] + "]");
  }
}
