package com.clarifi.phoenix.ashes.common;

import java.util.HashSet;
import java.util.Iterator;


/**
 *  A class the provides for a way to determine an Object's death in a
 *  synchronized (and thus thread-safe) way.
 */
public class Stoppable
{
  /** A private Object lock */
  private final Object _lock = new Object();

  private final HashSet _cascadedSignalers = new HashSet();

  /** A flag to determine if the com.clarifi.phoenix.ashes.common.Stoppable has been stopped. */
  private volatile boolean _stayAlive = true;

  /** A flag to determine if the com.clarifi.phoenix.ashes.common.Stoppable has been wakened from sleep. */
  private volatile boolean _wakeUp = false;

  /** serves as a way to signal any stoppable with a code */
  private volatile int _signal = 0;

  /**
   * Adds the {@link Object} to a list to be signaled when signalDeath() is called on this {@link Stoppable}.
   * Note: Only signalDeath() is cascaded, not signal(int).
   * @param cascade a {@link Stoppable} to signal if this {@link Stoppable} is signaled or {@link Object}
   * to be notified when this {@link Stoppable} is signaled.
   * @see #signalDeath()
   */
  public void addCascadedSingnaler(Object cascade)
  {
    synchronized (_lock)
    {
      _cascadedSignalers.add(cascade);
    }
  }

  /**
   * Remove the {@link Object} from from the list of objects to be signaled.
   * @param cascade
   * @return if the {@link Object} existed as a cascaded signaler
   */
  public boolean removeCascadedSignaler(Object cascade)
  {
    synchronized (_lock)
    {
      return _cascadedSignalers.remove(cascade);
    }
  }

  /**
   * Signals death by setting the alive flag to false.
   */
  public final void signalDeath()
  {
    HashSet cascades = null;
    synchronized (_lock)
    {
      _stayAlive = false;

      //shallow copy
      cascades = (HashSet)_cascadedSignalers.clone();

      //notify any fluid sleepers
      _lock.notifyAll();
    }

    int numCascades = cascades.size();
    if (numCascades > 0)
    {
      for (Iterator iter = cascades.iterator(); iter.hasNext(); )
      {
        Object cascade = iter.next();
        if (cascade instanceof Stoppable)
        {
          ((Stoppable)cascade).signalDeath();
        }

        //also signal it directly, whatever object it is (this is necessary if
        //  it is a Thread object that is being waited on)
        synchronized(cascade)
        {
          cascade.notifyAll();
        }
      }
    }
  }

  /**
   * Brings us back from the dead.
   */
  public final void resuscitate()
  {
    synchronized (_lock)
    {
      _stayAlive = true;

      //notify any fluid sleepers
      _lock.notifyAll();
    }
  }

  /**
   * Sets the signal code
   * @param signalCode the code to signal
   */
  public final void signal(int signalCode)
  {
    synchronized (_lock)
    {
      _signal = signalCode;
    }
  }

  /** Resets the signal code to 0 */
  public final void resetSignal()
  {
    synchronized (_lock)
    {
      _signal = 0;
    }
  }

  /** @return the signal code */
  public final int getSignal()
  {
    synchronized (_lock)
    {
      return _signal;
    }
  }

  /** @return true if signaled (signal code is not 0), false otherwise. */
  public final boolean isSignaled()
  {
    synchronized (_lock)
    {
      return _signal != 0;
    }
  }

  /**
   * Helper method that will throw a com.clarifi.phoenix.ashes.common.UserCancelledException if the com.clarifi.phoenix.ashes.common.Stoppable
   * has been signaled dead.
   * @param message the message that will be passed into the com.clarifi.phoenix.ashes.common.UserCancelledException,
   * if necessary
   * @throws UserCancelledException if stillAlive() is false
   */
  public final void throwIfDead(String message) throws UserCancelledException
  {
    if (!stillAlive())
    {
      throw new UserCancelledException(message);
    }
  }

  /**
   * Helper method that will throw a com.clarifi.phoenix.ashes.common.UserCancelledException if the com.clarifi.phoenix.ashes.common.Stoppable
   * has been signaled dead.
   * @throws UserCancelledException if stillAlive() is false
   */
  public final void throwIfDead() throws UserCancelledException
  {
    throwIfDead("User cancelled");
  }


  /**
   * wakes up the thread if it is sleeping
   */
  public final void wakeUp()
  {
    synchronized (_lock)
    {
      _wakeUp = true;

      //notify any fluid sleepers
      _lock.notifyAll();
    }
  }

  /** @return true if still alive, false otherwise */
  public final boolean stillAlive()
  {
    return _stayAlive;
  }

  /** @return true if thread was woken up, false otherwise */
  public final boolean awoken()
  {
    return _wakeUp;
  }

  /**
   * Just a helper method so Stoppables don't have to pass in themselves.
   * @param  millis  The amount of time, in milliseconds, to sleep
   * @return true if the method slept the specified amount of time,
   *         false if the com.clarifi.phoenix.ashes.common.Stoppable was stopped early.
   */
  public final boolean fluidSleep(long millis)
  {
    return fluidSleep(this, millis);
  }

  /**
   * Sleeps for the specified amount of time (in milliseconds), but checks the
   * given com.clarifi.phoenix.ashes.common.Stoppable to make sure we are still alive.
   *
   * @param  stopper  The com.clarifi.phoenix.ashes.common.Stoppable to check for early death.
   * @param  millis   The amount of milliseconds to sleep.
   * @return          true if we successfully slept for about the desired amount
   *                  of time, false if we died while we were sleeping.
   */
  public final static boolean fluidSleep(Stoppable stopper, long millis)
  {
    //snag a reference to the lock
    Object lock = stopper._lock;

    //when should we stop sleeping??
    long timeToEnd = System.currentTimeMillis() + millis;

    //how long should we wait?
    long nextWait = timeToEnd - System.currentTimeMillis();

    //loop until done
    while(nextWait > 0)
    {
      synchronized (lock)
      {
        //are we dead yet?
        if (!stopper._stayAlive)
          return false;

        stopper._wakeUp = false;

        //ok - we are not dead, so try to wait until then
        try {lock.wait(nextWait);} catch (Exception ex) {/** Ignore */}

        if (stopper._wakeUp)
          return false; //we were woken up
      }

      //have we slept long enough? if not, wait again
      nextWait = timeToEnd - System.currentTimeMillis();
    }

    //we slept the desired amount of time
    return true;
  }

  /**
   * @return The object lock used for signaling and waiting on this {@link Stoppable}
   */
  protected Object getLock()
  {
    return _lock;
  }

  public static class DeathSignaledException extends RuntimeException
  {
    public DeathSignaledException(){}
    public DeathSignaledException(String msg){super(msg);}
    public DeathSignaledException(String msg, Throwable cause){super(msg, cause);}
  }
}
