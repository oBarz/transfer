package com.clarifi.phoenix.ashes.node;

import com.clarifi.common.application.App;
import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteServices;
import org.apache.ignite.Ignition;
import org.apache.ignite.configuration.IgniteConfiguration;

import java.util.concurrent.*;

public class NodeApp {
    private volatile boolean stopped;
    private IgniteServices services;
    private Ignite ignite;
    private int serverId;

    public NodeApp() {
        stopped = false;
    }

    public boolean isStopped() {
        return stopped;
    }

    public static void main(final String[] args) throws Throwable {
        App.initBeforeAnythingElse(args, 0, "Node App", "1.0.0");

        final NodeApp node = new NodeApp();
        node.serverId = Integer.parseInt(args[0]);

        final App app = App.appMain(node::startup, node::shutdown);
    }

    private void startup(){
        final IgniteConfiguration cfg = new IgniteConfiguration();

        cfg.setClientMode(false);
        cfg.setPeerClassLoadingEnabled(true);

        final String serverName = "server-" + serverId;
        cfg.setIgniteInstanceName(serverName);
        cfg.setWorkDirectory("c:/tmp/" + serverName);

        ignite = Ignition.start(cfg);
        System.out.printf(
                ">> Started the server node: Name %s; Id: %s\n",
                serverName,
                ignite.cluster().node().id()
        );

        System.out.printf("\tNode ID: %s\n\tOS: %s\tJRE: %s\n",
                ignite.cluster().localNode().id(),
                System.getProperty("os.name"),
                System.getProperty("java.runtime.name")
        );

        services = ignite.services(ignite.cluster().forServers());
        services.deployNodeSingleton("MyExecutorService", new SimpleExecutorImpl());

        while (!this.isStopped()) {
            try {
                TimeUnit.SECONDS.sleep(10L);
            } catch (final InterruptedException ignore) {
            }
        }
    }
    private void shutdown(){
        services.cancelAll();
        ignite.close();
    }
}
