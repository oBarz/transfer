package com.phoenix.repl;

import com.amazon.ion.IonReader;
import com.amazon.ion.IonType;
import com.amazon.ion.IonWriter;
import com.amazon.ion.Timestamp;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static com.phoenix.repl.ClientRequestServlet.transactionThreadMap;

public interface CommandInterface {
    String getName();
    void execute() throws IOException;
    void setDesc(String desc);
    void toIon( IonWriter ionWriter) throws IOException;
    CommandInterface decodeCommand(IonReader ionReader, int transactionId);
    public String getDescription();
    public int getTransactionId();
}

class AddCommand implements CommandInterface{
    private static CommandTemplate commandTemplate;
    private static void init(){
        CommandTemplate.Parameter parameter1 = new CommandTemplate.Parameter("num1", "first integer","int", true);
        CommandTemplate.Parameter parameter2 = new CommandTemplate.Parameter("num2", "second integer","int", true);
        List<CommandTemplate.Parameter> parameterList = new ArrayList<>();
        parameterList.add(parameter1);
        parameterList.add(parameter2);

        commandTemplate = new CommandTemplate("add", "Calculate the sum of two integers", "double", parameterList);
    }
    private static final String name = "add";
    private volatile int result;
    private int num1;
    private int num2;
    private int transactionId;
    String desc = "The sum of the integers is: ";
    AddCommand(){
        this(0,0,0);
        init();
    }
    AddCommand(int num1, int num2, int transactionId){
        this.num1 = num1;
        this.num2 = num2;
        this.transactionId = transactionId;
    }
    @Override
    public String getName() {
        return name;
    }
    @Override
    public void execute() throws IOException {
        this.result = num1 + num2;
    }
    @Override
    public void setDesc(String desc) {
        this.desc = desc;
    }
    @Override
    public void toIon(IonWriter ionWriter) throws IOException {

        ionWriter.setFieldName("commandResult");
        ionWriter.stepIn(IonType.STRUCT);

        ionWriter.setFieldName(String.valueOf(Constants.result));
        ionWriter.writeFloat(this.result);

        ionWriter.setFieldName(String.valueOf(Constants.resultDescription));
        ionWriter.writeString(this.desc);

        ionWriter.stepOut();
    }
    @Override
    public CommandInterface decodeCommand(IonReader ionReader, int transactionId) {
        if(ionReader.next() != null)
            num1 = ionReader.intValue();
        if(ionReader.next() != null)
            num2 = ionReader.intValue();

        ionReader.stepOut();
        return new AddCommand(num1, num2, transactionId);
    }
    public String getDescription(){
        return commandTemplate.getCommandTemplateAsJsonString();
    }

    @Override
    public int getTransactionId() {
        return this.transactionId;
    }
}
class SubCommand implements CommandInterface{
    private static CommandTemplate commandTemplate;
    private static void init(){
        CommandTemplate.Parameter parameter1 = new CommandTemplate.Parameter("num1", "first integer","int", true);
        CommandTemplate.Parameter parameter2 = new CommandTemplate.Parameter("num2", "second integer","int", true);
        List<CommandTemplate.Parameter> parameterList = new ArrayList<>();
        parameterList.add(parameter1);
        parameterList.add(parameter2);

        commandTemplate = new CommandTemplate("sub", "Calculate the difference of two integers", "double", parameterList);
    }
    private static String name = "sub";
    private volatile int result;
    private int num1;
    private int num2;
    private int transactionId;
    String desc = "The difference of the integers is: ";
    SubCommand(){
        this(0,0,0);
        init();
    }
    SubCommand(int num1, int num2, int transactionId){
        this.num1 = num1;
        this.num2 = num2;
        this.transactionId = transactionId;
    }
    @Override
    public String getName() {
        return name;
    }
    @Override
    public void execute() {

        try {
            Thread.sleep(15000);

            Map<Integer, CommandAction> cache = ClientRequestServlet.getCache();

        if(cache.containsKey(transactionId)){
            CommandAction commandAction = cache.get(transactionId);

            commandAction.getCommandInterface().setDesc("The operation has completed 50%, Please use the transaction Id ("+transactionId+") " +
                    "to check the status of transaction in after few seconds");
            commandAction.setLastUpdated(Timestamp.now());
            commandAction.setStatus("inProgress");
        }
        Thread.sleep(20000);

        if(cache.containsKey(transactionId)){
            CommandAction commandAction = cache.get(transactionId);

            this.result = num1 - num2;

            commandAction.setCommandInterface(this);
            commandAction.setLastUpdated(Timestamp.now());
            commandAction.setStatus("success");
        }
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
    @Override
    public void setDesc(String desc) {
        this.desc = desc;
    }
    @Override
    public void toIon(IonWriter ionWriter) throws IOException {
        ionWriter.setFieldName("commandResult");
        ionWriter.stepIn(IonType.STRUCT);

        ionWriter.setFieldName(String.valueOf(Constants.result));
        ionWriter.writeFloat(this.result);

        ionWriter.setFieldName(String.valueOf(Constants.resultDescription));
        ionWriter.writeString(this.desc);

        ionWriter.stepOut();
    }
    @Override
    public CommandInterface decodeCommand(IonReader ionReader, int transactionId) {

        if(ionReader.next() != null)
            num1 = ionReader.intValue();
        if(ionReader.next() != null)
            num2 = ionReader.intValue();

        ionReader.stepOut();
        return new SubCommand(num1, num2, transactionId);
    }

    public String getDescription(){
        return commandTemplate.getCommandTemplateAsJsonString();
    }

    @Override
    public int getTransactionId() {
        return this.transactionId;
    }
}
class MulCommand implements CommandInterface{
    private static CommandTemplate commandTemplate;
    private static void init(){
        CommandTemplate.Parameter parameter1 = new CommandTemplate.Parameter("num1", "first integer","int", true);
        CommandTemplate.Parameter parameter2 = new CommandTemplate.Parameter("num2", "second integer","int", true);
        List<CommandTemplate.Parameter> parameterList = new ArrayList<>();
        parameterList.add(parameter1);
        parameterList.add(parameter2);

        commandTemplate = new CommandTemplate("mul", "Calculate the product of two integers", "int", parameterList);
    }
    private static String name = "mul";
    private volatile int result;
    private int num1;
    private int num2;
    private int transactionId;
    String desc = "The product of the integers is: ";
   MulCommand(){
       this(0,0,0);
       init();
   }
    MulCommand(int num1, int num2, int transactionId){
        this.num1 = num1;
        this.num2 = num2;
        this.transactionId = transactionId;
    }
    @Override
    public String getName() {
        return name;
    }
    @Override
    public void execute() throws IOException {
        this.result = num1 * num2;
    }
    @Override
    public void setDesc(String desc) {
        this.desc = desc;
    }
    @Override
    public void toIon(IonWriter ionWriter) throws IOException {
        ionWriter.setFieldName("commandResult");
        ionWriter.stepIn(IonType.STRUCT);

        ionWriter.setFieldName(String.valueOf(Constants.result));
        ionWriter.writeFloat(this.result);

        ionWriter.setFieldName(String.valueOf(Constants.resultDescription));
        ionWriter.writeString(this.desc);

        ionWriter.stepOut();
    }
    @Override
    public CommandInterface decodeCommand(IonReader ionReader, int transactionId) {

        if(ionReader.next() != null)
            num1 = ionReader.intValue();
        if(ionReader.next() != null)
            num2 = ionReader.intValue();

        ionReader.stepOut();
        return new MulCommand(num1, num2, transactionId);
    }
    public String getDescription(){
        return commandTemplate.getCommandTemplateAsJsonString();
    }

    @Override
    public int getTransactionId() {
        return this.transactionId;
    }
}

class DivCommand implements CommandInterface{
    private static CommandTemplate commandTemplate;
    private static void init(){
        CommandTemplate.Parameter parameter1 = new CommandTemplate.Parameter("num1", "first integer","int", true);
        CommandTemplate.Parameter parameter2 = new CommandTemplate.Parameter("num2", "second integer","int", true);
        List<CommandTemplate.Parameter> parameterList = new ArrayList<>();
        parameterList.add(parameter1);
        parameterList.add(parameter2);

        commandTemplate = new CommandTemplate("div", "Divide the integers (first/second)", "double", parameterList);
    }
    private static String name = "div";
    private volatile double result;
    private int num1;
    private int num2;
    private int transactionId;
    String desc = "The division of the integers (num1/num2) is: ";
    DivCommand(){
        this(0,0,0);
        init();
    }
    DivCommand(int num1, int num2, int transactionId){
        this.num1 = num1;
        this.num2 = num2;
        this.transactionId = transactionId;
    }
    @Override
    public String getName() {
        return name;
    }
    @Override
    public void execute() throws IOException {
        this.result = num1 / num2;
    }
    @Override
    public void setDesc(String desc) {
        this.desc = desc;
    }
    @Override
    public void toIon(IonWriter ionWriter) throws IOException {
        ionWriter.setFieldName("commandResult");
        ionWriter.stepIn(IonType.STRUCT);

        ionWriter.setFieldName(String.valueOf(Constants.result));
        ionWriter.writeFloat(this.result);

        ionWriter.setFieldName(String.valueOf(Constants.resultDescription));
        ionWriter.writeString(this.desc);

        ionWriter.stepOut();
    }
    @Override
    public CommandInterface decodeCommand(IonReader ionReader, int transactionId) {

        if(ionReader.next() != null)
            num1 = ionReader.intValue();
        if(ionReader.next() != null)
            num2 = ionReader.intValue();
        ionReader.stepOut();
        return new DivCommand(num1, num2, transactionId);
    }
    public String getDescription(){
        return commandTemplate.getCommandTemplateAsJsonString();
    }

    @Override
    public int getTransactionId() {
        return this.transactionId;
    }
}
class GetObj implements CommandInterface{
    private static CommandTemplate commandTemplate;
    private static void init(){
        commandTemplate = new CommandTemplate("getobj", "Command with the result in the form of object, printed as json", "java.lang.Object", null);
    }
    private static String name = "getobj";
    GetObj(){
        init();
    }
    private class Person{
        private String name = "tom";
        private int age = 21;
        Person(String name, int age){
            this.name = name;
            this.age = age;
        }
        String getName(){
            return name;
        }
        int getAge(){
            return age;
        }
    }
    private volatile Person result;
    String desc = "The contents of the object are: ";
    @Override
    public String getName() {
        return name;
    }
    @Override
    public void execute() {
        result = new Person("tom",21);
    }
    @Override
    public void setDesc(String desc) {
        this.desc = desc;
    }
    @Override
    public void toIon(IonWriter ionWriter) throws IOException {
        ionWriter.setFieldName("commandResult");
        ionWriter.stepIn(IonType.STRUCT);

        ionWriter.setFieldName(String.valueOf(Constants.result));

        ionWriter.stepIn(IonType.STRUCT);
        ionWriter.setFieldName("name");
        ionWriter.writeString(result.getName());
        ionWriter.setFieldName("age");
        ionWriter.writeInt(result.getAge());
        ionWriter.stepOut();

        ionWriter.setFieldName(String.valueOf(Constants.resultDescription));
        ionWriter.writeString(this.desc);

        ionWriter.stepOut();
    }
    @Override
    public CommandInterface decodeCommand(IonReader ionReader, int transactionId) {
        return this;
    }
    public String getDescription(){

        return commandTemplate.getCommandTemplateAsJsonString();
    }

    @Override
    public int getTransactionId() {
        return 0;
    }
}
class CancelCommand implements CommandInterface{
    private static CommandTemplate commandTemplate;
    private static void init(){
        CommandTemplate.Parameter parameter1 = new CommandTemplate.Parameter("transactionId", "first integer","int", true);
        List<CommandTemplate.Parameter> parameterList = new ArrayList<>();
        parameterList.add(parameter1);

        commandTemplate = new CommandTemplate("cancel", "Cancel (or Terminate) a transaction", "double", parameterList);
    }
    CancelCommand(){
        this(0);
        init();
    }
    CancelCommand(int transactionId){
        this.transactionId = transactionId;
    }
    private int transactionId;
    private static String name = "cancel";
    private String desc;
    @Override
    public String getName() {
        return name;
    }
    @Override
    public void execute() throws IOException {
            Thread thread = transactionThreadMap.get(transactionId);
            try {
                thread.interrupt();
            }catch (Exception e){
                System.out.println("The transaction ("+transactionId+") has been terminated");
            }finally {
                this.desc = "The transaction ("+transactionId+") has been terminated";

                transactionThreadMap.remove(transactionId);
            }
    }
    @Override
    public void setDesc(String desc) {

    }
    @Override
    public void toIon(IonWriter ionWriter) throws IOException {
        ionWriter.setFieldName("commandResult");
        ionWriter.stepIn(IonType.STRUCT);

        ionWriter.setFieldName(String.valueOf(Constants.resultDescription));
        ionWriter.writeString(this.desc);

        ionWriter.stepOut();
    }

    @Override
    public CommandInterface decodeCommand(IonReader ionReader, int transactionId) {
        if(ionReader.next() != null)
            transactionId = ionReader.intValue();
        return new CancelCommand(transactionId);
    }

    @Override
    public String getDescription() {
        return commandTemplate.getCommandTemplateAsJsonString();
    }

    @Override
    public int getTransactionId() {
        return this.transactionId;
    }
}

class StatusCommand implements CommandInterface{
    private static CommandTemplate commandTemplate;
    private static void init(){
        CommandTemplate.Parameter parameter1 = new CommandTemplate.Parameter("transactionId", "first integer","int", true);
        List<CommandTemplate.Parameter> parameterList = new ArrayList<>();
        parameterList.add(parameter1);

        commandTemplate = new CommandTemplate("status", "Check the status of a transaction", "double", parameterList);
    }
    StatusCommand(){
        this(0);
        init();
    }
    StatusCommand(int transactionId){
        this.transactionId = transactionId;
    }
    private int transactionId;
    private static String name = "status";
    private String desc;
    @Override
    public String getName() {
        return name;
    }
    @Override
    public void execute() throws IOException {
        this.desc =  "The transaction ("+transactionId+") has either been completed in the past " +
                "or has been terminated";
    }
    @Override
    public void setDesc(String desc) {

    }
    @Override
    public void toIon(IonWriter ionWriter) throws IOException {
        ionWriter.setFieldName("commandResult");
        ionWriter.stepIn(IonType.STRUCT);

        ionWriter.setFieldName(String.valueOf(Constants.resultDescription));
        ionWriter.writeString(this.desc);

        ionWriter.stepOut();
    }

    @Override
    public CommandInterface decodeCommand(IonReader ionReader, int transactionId) {
        if(ionReader.next() != null)
            transactionId = ionReader.intValue();
        return new StatusCommand(transactionId);
    }

    @Override
    public String getDescription() {
        return commandTemplate.getCommandTemplateAsJsonString();
    }

    @Override
    public int getTransactionId() {
        return this.transactionId;
    }
}
class NoOpCommand implements CommandInterface{
    String desc;
    public void setDesc(String desc) {
        this.desc = desc;
    }
    @Override
    public void toIon(IonWriter ionWriter) throws IOException {
        ionWriter.setFieldName("commandResult");
        ionWriter.stepIn(IonType.STRUCT);

        ionWriter.setFieldName(String.valueOf(Constants.resultDescription));
        ionWriter.writeString(this.desc);

        ionWriter.stepOut();
    }
    @Override
    public CommandInterface decodeCommand(IonReader ionReader, int transactionId) {
        return this;
    }
    @Override
    public String getDescription() {
        return null;
    }

    @Override
    public int getTransactionId() {
        return 0;
    }

    NoOpCommand(String desc){
        this.desc = desc;
    }
    @Override
    public String getName() {
        return null;
    }
    @Override
    public void execute() {
        //No-op
    }
}