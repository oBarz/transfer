package com.phoenix.repl;

public class Constants {

    public static final char name = 'n';
    public static final char description = 'd';
    public static final char type = 't';
    public static final char parameters = 'p';
    public static final char required = 'q';
    public static final char status = 's';
    public static final char transactionId = 'x';
    public static final char lastUpdated = 'l';
    public static final char result = 'r';
    public static final char resultDescription = 'y';

}
