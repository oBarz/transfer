package com.phoenix;

import com.amazon.ion.*;
import com.amazon.ion.system.IonSystemBuilder;
import org.jline.builtins.ConfigurationPath;
import org.jline.console.SystemRegistry;
import org.jline.console.impl.SystemRegistryImpl;
import org.jline.console.impl.Builtins;
import org.jline.reader.*;
import org.jline.reader.impl.DefaultHighlighter;
import org.jline.reader.impl.DefaultParser;
import org.jline.reader.impl.completer.NullCompleter;
import org.jline.terminal.Terminal;
import org.jline.terminal.TerminalBuilder;
import org.jline.widget.AutosuggestionWidgets;
import picocli.CommandLine;
import picocli.CommandLine.Model.CommandSpec;
import picocli.CommandLine.Model.OptionSpec;
import picocli.CommandLine.Model.PositionalParamSpec;
import picocli.shell.jline3.PicocliCommands;

import java.io.*;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;
import java.util.function.Supplier;
import java.util.zip.GZIPOutputStream;

import com.phoenix.CommandModel.Parameter;

public class Client {

  static final HttpClient httpClient = HttpClient.newHttpClient();
  private static void initializeSubCommands(CommandLine repl) throws Exception {

        byte [] ionFormatCommand =  getIonFormatSerializedObject(Arrays.asList("init"), null);

        List<CommandModel> listOfCommandsToBeInitialized = null;

        try {
            HttpRequest postRequest = HttpRequest.newBuilder()
                            .uri(URI.create("http://localhost:8080/ServerForCli/API"))
                    .POST(HttpRequest.BodyPublishers.ofByteArray(ionFormatCommand))
                    .build();

            HttpResponse<InputStream> response = httpClient.send(postRequest, HttpResponse.BodyHandlers.ofInputStream());

            listOfCommandsToBeInitialized = CommandModel.inputStreamToInitCommands(response.body());

        }catch(InterruptedException | ClassNotFoundException e){
            throw new RuntimeException(e);
        }

      //add subcommands

      ServerCommand subCommand;
      CommandSpec spec;
      CommandLine cmdLine;


        for(CommandModel cmd : listOfCommandsToBeInitialized) {

            if(!cmd.getCommandName().equalsIgnoreCase("status") && !cmd.getCommandName().equalsIgnoreCase("cancel")){
            subCommand = new ServerCommand();
            spec = CommandSpec.wrapWithoutInspection(subCommand);

            int indx = 0;
            for (Parameter parameter : cmd.getParameters()) {
                String typeAsString = parameter.getType();
                Class<?> classType = null;
                if (typeAsString.equals("Integer") || typeAsString.equals("int"))
                    classType = int.class;//Integer.class;
                else if (typeAsString.equals("String"))
                    classType = String.class;
                PositionalParamSpec.Builder builder = PositionalParamSpec.builder();
                builder.paramLabel(parameter.getName());
                builder.description(parameter.getDescription());
                spec.addPositional(builder.index(Integer.toString(indx)).type(classType).required(parameter.isRequired()).build());
                indx++;
            }
            spec.addOption(OptionSpec.builder("-h", "---help")
                    .usageHelp(true)
                    .description(cmd.getDescription())
                    .build());
            subCommand.spec = spec;
            subCommand.returnType = cmd.returnType;
            cmdLine = new CommandLine(spec);
            repl.addSubcommand(cmd.getCommandName(), cmdLine).setSubcommandsCaseInsensitive(true);
            // repl.setSubcommandsCaseInsensitive(true);
        }
        }
    }
        static CmdResult invokeOperationOnServer(byte [] ionFormatCommand) {

            CmdResult commandResult = null;
            try
            {
                HttpRequest postRequest = HttpRequest.newBuilder()
                        .uri(URI.create("http://localhost:8080/ServerForCli/API"))
                        .POST(HttpRequest.BodyPublishers.ofByteArray(ionFormatCommand))
                        .build();

                HttpResponse<InputStream> response = httpClient.send(postRequest, HttpResponse.BodyHandlers.ofInputStream());

                  if(response != null)
                        commandResult = CmdResult.convertFromGZippedIonFormat(response.body());

            } catch (IOException | InterruptedException e) {
                e.printStackTrace();
            }
            return commandResult;
        }
    private static byte [] getIonFormatSerializedObject(List<String> command, List<PositionalParamSpec> parameters) throws Exception {
        IonSystem ionSystem = IonSystemBuilder.standard().build();

        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        GZIPOutputStream gzipOutputStream = new GZIPOutputStream(byteArrayOutputStream);
        IonWriter ionWriter = ionSystem.newBinaryWriter(gzipOutputStream);

        ionWriter.stepIn(IonType.STRUCT);
        ionWriter.setFieldName("command");
        ionWriter.writeString(command.get(0));

        for (int i = 1; i < command.size(); i++){
            String type = parameters.get(i - 1).type().getTypeName();
            switch (type){
                case "int" :
                                         ionWriter.setFieldName("param_"+i);
                                         ionWriter.writeInt(Integer.parseInt(command.get(i)));
                                         break;
                case "java.lang.String"  :
                                         ionWriter.setFieldName("param_"+i);
                                         ionWriter.writeString(command.get(i));
                                         break;
                case "double"  :
                                         ionWriter.setFieldName("param_"+i);
                                         ionWriter.writeFloat(Float.parseFloat(command.get(i)));
                                         break;
                default:
                        throw new Exception("Parameter Type Not Defined");
            }
        }


        ionWriter.stepOut();
        ionWriter.close();

        gzipOutputStream.close();
        byteArrayOutputStream.close();

        return byteArrayOutputStream.toByteArray();
    }
    static class CancelCommand implements Runnable {
        CommandSpec spec;

        @Override
        public void run() {
            CommandLine.ParseResult pr = spec.commandLine().getParseResult();
            List<String> command = pr.originalArgs();
            try {
                byte [] ionFormatCommand =  getIonFormatSerializedObject(command, spec.positionalParameters());
                CmdResult commandResult = invokeOperationOnServer(ionFormatCommand);
                 if (commandResult.getStatus() == CmdResult.Status.success)
                     System.out.println(commandResult.getDesc() + commandResult.getResult());
                 else
                     System.out.println(commandResult.getDesc());
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
    }

    static class ServerCommand implements Runnable{
      CommandSpec spec;
      Class<?> returnType;

      public void run(){
          CommandLine.ParseResult pr = spec.commandLine().getParseResult();
          List<String> command = pr.originalArgs();
          try {
              List<PositionalParamSpec> parameters = spec.positionalParameters();

              byte [] ionFormatCommand =  getIonFormatSerializedObject(command,parameters);
             CmdResult commandResult = invokeOperationOnServer(ionFormatCommand);
              if (commandResult.getStatus() == CmdResult.Status.success)
                  System.out.println(commandResult.getDesc() + commandResult.getResult());
              else
                  System.out.println(commandResult.getDesc());
          } catch (Exception e) {
              throw new RuntimeException(e);
          }
      }
    }
    static class StatusCommand implements Runnable{
        CommandSpec spec;
        @Override
        public void run() {
            CommandLine.ParseResult pr = spec.commandLine().getParseResult();
            List<String> command = pr.originalArgs();
            try {
                byte [] ionFormatCommand =  getIonFormatSerializedObject(command, spec.positionalParameters());
                CmdResult commandResult = invokeOperationOnServer(ionFormatCommand);
                if (commandResult.getStatus() == CmdResult.Status.success)
                    System.out.println(commandResult.getDesc() + commandResult.getResult());
                else
                    System.out.println(commandResult.getDesc());
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
    }

    public static void main(String... args) throws Exception {

        StatusCommand statusCommand = new StatusCommand();
        CommandSpec spec = CommandSpec.wrapWithoutInspection(statusCommand);
        spec.addPositional(PositionalParamSpec.builder().index("0").paramLabel("firstInt").type(int.class).required(true).build());
        statusCommand.spec = spec;
        CommandLine statusCommandLine = new CommandLine(spec);

        CancelCommand cancelCommand = new CancelCommand();
        spec = CommandSpec.wrapWithoutInspection(cancelCommand);
        spec.addPositional(PositionalParamSpec.builder().index("0").paramLabel("firstInt").type(int.class).required(true).build());
        cancelCommand.spec = spec;
        CommandLine cancelCommandLine = new CommandLine(spec);

        // Register shutdown hook
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            System.out.println("Closing HTTP client...");
            try {
           //     httpClient.close();
            } catch (Exception e) {
                System.err.println("Error closing HTTP client: " + e.getMessage());
            }
            System.out.println("HTTP client closed.");
        }));

        Client client = new Client();
        CommandSpec cSpec1 = CommandSpec.wrapWithoutInspection(client);
        CommandLine cmd = new CommandLine(cSpec1);//, factory);
        cmd.addSubcommand("status", statusCommandLine);
        cmd.addSubcommand("cancel", cancelCommandLine);

        initializeSubCommands(cmd);

        PicocliCommands picocliCommands = new PicocliCommands(cmd);
        picocliCommands.name("Commands");


        Supplier<Path> workDir = () -> Paths.get(System.getProperty("user.dir"));
        ConfigurationPath configPath = new ConfigurationPath(Paths.get("C:\\Users\\harsh\\IdeaProjects\\FirstCli"),   // application-wide settings
                Paths.get(System.getProperty("user.home")));
       // DefaultHighlighter highlighter = new DefaultHighlighter();
        Builtins builtins = new Builtins(workDir, configPath, null);
       /* builtins.rename(Builtins.Command.TTOP, "top");
        builtins.alias("zle", "widget");
        builtins.alias("bindkey", "keymap");*/


        Parser parser = new DefaultParser();
        try(Terminal terminal = TerminalBuilder.builder().build()){
            SystemRegistry systemRegistry = new SystemRegistryImpl(parser, terminal, workDir, null);
            systemRegistry.setCommandRegistries(builtins, picocliCommands);
            systemRegistry.register("help", picocliCommands);


            LineReader reader = LineReaderBuilder.builder()
                    .terminal(terminal)
                    .completer(systemRegistry.completer())
                    .parser(parser)
                    //   .completer(systemCompleter)
                    .variable(LineReader.LIST_MAX, 50)
                    .build();

        //    factory.setTerminal(terminal);


            AutosuggestionWidgets autosuggestionWidgets = new AutosuggestionWidgets(reader);
// Enable autosuggestions
            autosuggestionWidgets.enable();
            autosuggestionWidgets.setSuggestionType(LineReader.SuggestionType.COMPLETER);

           /* KeyMap<Binding> keyMap = reader.getKeyMaps().get("main");
            keyMap.bind(new Reference("tailtip-toggle"), KeyMap.alt("s"));*/

            String prompt = "prompt> ";
            String rightPrompt = null;

            String line;
            while(true){
                systemRegistry.cleanUp();
                line = reader.readLine(prompt, rightPrompt, (MaskingCallback) null, null);


                systemRegistry.execute(line);
            }
        }catch (Throwable t) {
            if(t instanceof EndOfFileException)
                System.out.println("Exiting the CLI App");
            else
                t.printStackTrace();
        }
        System.exit(0);
    }
}