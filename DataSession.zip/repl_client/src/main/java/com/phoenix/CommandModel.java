package com.phoenix;

import com.amazon.ion.*;
import com.amazon.ion.system.IonSystemBuilder;

import java.io.InputStream;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;

public class CommandModel {
    String commandName;
    String description;
    List<Parameter> parameters;
    Class<?> returnType;
    CommandModel(String commandName, String description, List<Parameter> parameters, Class<?> returnType){
        this.commandName = commandName;
        this.description = description;
        this.parameters = parameters;
        this.returnType = returnType;
    }
    public String getCommandName() {
        return commandName;
    }
    public void setCommandName(String commandName) {
        this.commandName = commandName;
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    public List<Parameter> getParameters() {
        return parameters;
    }
    public static List<CommandModel> inputStreamToInitCommands(InputStream inputStream) throws ClassNotFoundException {

        IonSystem ionSystem = IonSystemBuilder.standard().build();
        IonReader ionReader = ionSystem.newReader(inputStream);

        List<CommandModel> listOfInitCommands = new ArrayList<>();
        while (ionReader.next() != null) {
          //  ionReader.stepIn(); // Step into each object
            String commandName = "";
            String description = "";
            Class<?> returnType = null;
            List<Parameter> parameters = new ArrayList<>();

                String ionString = ionReader.stringValue();
                IonReader ionReaderForCommands = ionSystem.newReader(new StringReader(ionString));

                while (ionReaderForCommands.next() != null) {
                    ionReaderForCommands.stepIn();
                    while (ionReaderForCommands.next() != null){

                    char fieldName = ionReaderForCommands.getFieldName().charAt(0);
                    if (fieldName == Constants.name)
                        commandName = ionReaderForCommands.stringValue();
                    else if (fieldName == Constants.description)
                        description = ionReaderForCommands.stringValue();
                    else if (fieldName == Constants.type){
                        String type = ionReaderForCommands.stringValue();
                        if(type.equals("double"))
                            returnType = double.class;
                        else if(type.equals("int"))
                            returnType = int.class;
                        else
                            returnType = Class.forName(type);
                    }
                    else {
                        ionReaderForCommands.stepIn();

                        while (ionReaderForCommands.next() != null) {
                            Parameter parameter = new Parameter();
                            ionReaderForCommands.stepIn();
                            while (ionReaderForCommands.next() != null) {
                                fieldName = ionReaderForCommands.getFieldName().charAt(0);

                                switch (fieldName) {
                                    case Constants.name:
                                        parameter.setName(ionReaderForCommands.stringValue());
                                        break;
                                    case Constants.description:
                                        parameter.setDescription(ionReaderForCommands.stringValue());
                                        break;
                                    case Constants.type:
                                        parameter.setType(ionReaderForCommands.stringValue());
                                        break;
                                    case Constants.required:
                                        parameter.setRequired(ionReaderForCommands.booleanValue());
                                        break;
                                }
                            }
                            ionReaderForCommands.stepOut();
                            parameters.add(parameter);
                        }
                        ionReaderForCommands.stepOut();
                    }
                }
            }
                listOfInitCommands.add(new CommandModel(commandName, description, parameters, returnType));
                parameters = new ArrayList<>();
        }
        return listOfInitCommands;
    }

   static class Parameter {
        private String name;
        private String description;
        private String type;
        private boolean required;
       public String getName() {
           return name;
       }
       public void setName(String name) {
           this.name = name;
       }
       public String getDescription() {
           return description;
       }
       public void setDescription(String description) {
           this.description = description;
       }
       public String getType() {
           return type;
       }
       public void setType(String type) {
           this.type = type;
       }
       public boolean isRequired() {
           return required;
       }
       public void setRequired(boolean required) {
           this.required = required;
       }

       @Override
        public String toString() {
            return "Parameter{" +
                    "name='" + name + '\'' +
                    ", description='" + description + '\'' +
                    ", type='" + type + '\'' +
                    ", required=" + required +
                    '}';
        }
    }
}

