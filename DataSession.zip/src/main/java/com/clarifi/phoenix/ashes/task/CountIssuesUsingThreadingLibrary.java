package com.clarifi.phoenix.ashes.task;

import com.clarifi.concurrent.Unification;
import com.clarifi.concurrent.UnitedFuture;
import com.clarifi.concurrent.batch.BatchBuilder;
import com.clarifi.concurrent.batch.BatchingThreadPool;
import com.clarifi.concurrent.batch.DecompContinuousBatch;
import com.clarifi.concurrent.batch.task.*;
import com.clarifi.phoenix.ashes.common.PackedDataSession;
import org.apache.ignite.IgniteCache;

import javax.cache.Cache;
import java.util.Comparator;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;

public class CountIssuesUsingThreadingLibrary implements Callable<Integer> {
    private final IgniteCache<UUID, PackedDataSession> cache;
    private final BatchingThreadPool pool;

    public CountIssuesUsingThreadingLibrary(final IgniteCache<UUID, PackedDataSession> cache,
                                            final BatchingThreadPool pool) {
        this.cache = cache;
        this.pool = pool;
    }

    @Override
    public Integer call() throws Exception {
       /* final DecompContinuousBatch<Optional<Integer>, Integer> batch =
                BatchBuilder.builderForCollector(Unification.UniteOrFailOnFirstFailure,
                                Collectors.maxBy(Comparator.comparingInt(Integer::intValue)))
                        .forBatchType_DecompContinuous().buildForCollectorOrCompleterFunction();

        final UnitedFuture<Optional<Integer>, Integer> future = batch.submitToPool(pool);

        for (final Cache.Entry<UUID, PackedDataSession> entry : cache) {
            batch.addCallable(new Callable<Integer>() {
                @Override
                public Integer call() throws Exception {
                    final int[] issues = entry.getValue().getIssues();
                    if (issues == null || issues.length == 0) {
                        return Integer.valueOf(0);
                    }

                    return Integer.valueOf(issues.length);
                }
            });
        }

        batch.batchFullyDefined();
        Integer result = future.get().get();


        return result;*/
        final DecompContinuousBatch<Optional<Integer>, Integer> processingBatch =
                BatchBuilder.builderForCollector(Unification.UniteOrFailOnFirstFailure,
                                Collectors.maxBy(Comparator.comparingInt(Integer::intValue)))
                        .forBatchType_DecompContinuous().buildForCollectorOrCompleterFunction();

        UnitedFuture<Optional<Integer>, Integer> processFut = processingBatch.submitToPool(pool);

        for (final Cache.Entry<UUID, PackedDataSession> entry : cache) {

                    final int[] issues = entry.getValue().getIssues();

            int threshold = 1000;
            int start = 0, end = issues.length;

            while (start + threshold < end) {
                processingBatch.addCallable(new FindMaxTask(start, start + threshold, issues));
                start += threshold;
            }

            if (start < end - 1) {
                processingBatch.addCallable(new FindMaxTask(start, end - 1, issues));
            }
        }

        processingBatch.batchFullyDefined();
        Integer result = processFut.get().get().intValue();

        return result;
    }

    public void findMax(final int[] issues) {
        // start:- count issues using batches from threading library

        final DecompContinuousBatch<Optional<Integer>, Integer> processingBatch =
                BatchBuilder.builderForCollector(Unification.UniteOrFailOnFirstFailure,
                                Collectors.maxBy(Comparator.comparingInt(Integer::intValue)))
                        .forBatchType_DecompContinuous().buildForCollectorOrCompleterFunction();
        // .forBatchType_DecompContinuous().buildForCollectorOrCompleterFunction();

        UnitedFuture<Optional<Integer>, Integer> processFut = processingBatch.submitToPool(pool);

        int threshold = 1000;
        int start = 0, end = issues.length;

        while (start + threshold < end) {
            processingBatch.addCallable(new FindMaxTask(start, start + threshold, issues));
            start += threshold;
        }

        if (start < end - 1) {
            processingBatch.addCallable(new FindMaxTask(start, end - 1, issues));
        }

        processingBatch.batchFullyDefined();

        try {
            System.out.printf("Result of issue count: %d", processFut.get().get().intValue());
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        } catch (ExecutionException e) {
            throw new RuntimeException(e);
        }
        //end of the block
    }

    private final static class FindMaxTask extends DecompTask<Integer> {
        int [] issues;
        int start;
        int end;
        FindMaxTask(int start, int end, int [] issues){
            this.start = start;
            this.end = end;
            this.issues = issues;
            setComputeFunction(this::compute);
        }
        public TaskResult<Integer> compute(final DecompTask<Integer> task,
                                           final TaskContext<Integer> context) throws Exception{

            task.prepareScatter(0, this::continuation, Unification.UniteOrFailOnFirstFailure);


            int maximum = 0;
            for(int i = start; i < end; i++){
                maximum = Math.max(maximum,issues[i]);
            }
            int finalMaximum = maximum;
            task.scatterFor(0, () -> finalMaximum);

            task.scatterFullyDefined(0);

            return ContinuationResult.instanceOf();
        }

        private TaskResult<?> continuation(final DecompTask<Integer> task,
                                           final ContinuationContext<Integer> context,
                                           final TaskResult<?>[] results) throws Exception
        {
            int maximum = 0;
            for (int i = 0, n = results.length; i < n; i++)
            {
                TaskResult<?> res = results[i];
                if (res.isFailure())
                    throw ((FailedResult<?>)res).errAsException();

                SuccessfulResult<Integer> sRes = (SuccessfulResult<Integer>)res;
                maximum = Math.max(sRes.result(),maximum);
            }

            return SuccessfulResult.of(maximum);
        }

    }
}
