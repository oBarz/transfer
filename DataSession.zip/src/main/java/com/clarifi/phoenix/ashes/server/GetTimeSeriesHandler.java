package com.clarifi.phoenix.ashes.server;

import com.clarifi.phoenix.ashes.common.IssueDataSlicedByDataItem;
import com.clarifi.phoenix.ashes.common.PhoenixDate;
import com.clarifi.phoenix.ashes.data.TimeSeriesDataKey;
import io.undertow.server.HttpHandler;
import io.undertow.server.HttpServerExchange;
import io.undertow.util.PathTemplateMatch;
import io.undertow.util.StatusCodes;
import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteCompute;

import java.time.LocalDate;

public class GetTimeSeriesHandler implements HttpHandler {
    private final ServerApp server;

    public GetTimeSeriesHandler(final ServerApp server) {
        this.server = server;
    }

    @Override
    public void handleRequest(final HttpServerExchange exchange) throws Exception {
        PathTemplateMatch pathMatch = exchange.getAttachment(PathTemplateMatch.ATTACHMENT_KEY);
        final String issueId = pathMatch.getParameters().get("issueId");
        final String date = pathMatch.getParameters().get("date");
        final String dataItemId = pathMatch.getParameters().get("dataItemId");

        final Ignite ignite = server.getIgnite();
        final IgniteCompute compute = ignite.compute();

        final TimeSeriesDataKey key = new TimeSeriesDataKey(
            Integer.parseInt(issueId),
            Integer.parseInt(dataItemId)
        );

        final LocalDate localDate = LocalDate.parse(date);
        final PhoenixDate phDate = PhoenixDate.fromLocalDate(localDate);

        final IssueDataSlicedByDataItem result = compute.affinityCall(
            "TIME_SERIES",
            key,
            new GetTimeSeriesSlice(Integer.parseInt(issueId), Integer.parseInt(dataItemId), phDate)
        );

        exchange.setStatusCode(StatusCodes.OK);
        exchange.getResponseSender().send(String.format("Result: %s", result));

        exchange.endExchange();
    }
}
