package com.clarifi.phoenix.ashes.server;

import com.clarifi.phoenix.ashes.common.DataSession;
import com.clarifi.phoenix.ashes.common.PackedDataSession;
import io.undertow.server.HttpServerExchange;
import io.undertow.util.HeaderMap;
import io.undertow.util.HeaderValues;
import io.undertow.util.Headers;
import io.undertow.util.StatusCodes;
import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteCache;
import org.apache.ignite.IgniteException;
import org.apache.ignite.cache.CacheMode;
import org.apache.ignite.configuration.CacheConfiguration;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.UUID;
import java.util.zip.GZIPOutputStream;

public class CreateDataSessionHandler {
    protected static final String ENCODING_GZIP = "gzip";

    protected IgniteCache<UUID, PackedDataSession> getOrCreateUserCache(final Ignite ignite, final String userId) {
        final String userCacheName = String.format(
                "%s:%s", ServerApp.PREFIX_CACHE_USER_DATA_SESSIONS, userId);

        IgniteCache<UUID, PackedDataSession> cache = ignite.cache(userCacheName);
        if (cache == null) {
            final CacheConfiguration<UUID, PackedDataSession> cacheCfg = new CacheConfiguration<>(userCacheName);
            cacheCfg.setCacheMode(CacheMode.REPLICATED);

            cache = ignite.createCache(cacheCfg);
        }

        return cache;
    }

    protected void sendSessionStatus(final DataSession session, final HttpServerExchange exchange) {
        exchange.setStatusCode(StatusCodes.REQUEST_TIME_OUT);

        // todo: replace with actual job id and completion percentage
        exchange.getResponseSender().send(String.format(
            "The session '%s' is taking longer than usual, please check again shortly",
            session.getId()
        ));
    }

    protected void sendSessionError(final DataSession session, final IgniteException ex, final HttpServerExchange exchange) {
        exchange.setStatusCode(StatusCodes.INTERNAL_SERVER_ERROR);

        exchange.getResponseSender().send(ex.toString());
    }

    protected void sendSessionResult(final DataSession session, final Boolean result,
                                     final HttpServerExchange exchange) throws IOException {
        if (!result.booleanValue()) {
            exchange.setStatusCode(StatusCodes.INTERNAL_SERVER_ERROR);
            exchange.getResponseSender().send(String.format("Could not create session: %s", session));
        } else {
            System.out.printf("Data session created: %s\n", session);

            final ByteArrayOutputStream output = new ByteArrayOutputStream();
            final PackedDataSession.Writer writer;

            final boolean acceptsGZIP = acceptsGZIP(exchange.getRequestHeaders());
            if (acceptsGZIP) {
                writer = new PackedDataSession.IonWriter(session);
                writer.write(new GZIPOutputStream(output));
            } else {
                writer = new PackedDataSession.JsonWriter(session);
                writer.write(output);
            }

            final byte[] payload = output.toByteArray();

            exchange.getResponseHeaders().put(Headers.CONTENT_LENGTH, Integer.toString(payload.length));
            exchange.getResponseHeaders().put(Headers.CONTENT_TYPE, writer.getMimeType());

            exchange.setStatusCode(StatusCodes.OK);
            exchange.setResponseContentLength(payload.length);

            if (acceptsGZIP) {
                exchange.getResponseHeaders().put(Headers.CONTENT_ENCODING, ENCODING_GZIP);
                exchange.getResponseSender().send(ByteBuffer.wrap(payload));
            } else {
                exchange.getResponseSender().send(new String(payload), StandardCharsets.UTF_8);
            }
        }
    }

    protected boolean acceptsGZIP(final HeaderMap headers) {
        final HeaderValues acceptEncoding = headers.get(Headers.ACCEPT_ENCODING);
        if (acceptEncoding != null && acceptEncoding.contains(ENCODING_GZIP)) {
            return true;
        }

        return false;
    }
}
