package com.clarifi.phoenix.ashes.util;

import com.clarifi.phoenix.ashes.common.Common;
import com.clarifi.phoenix.ashes.data.IssueData;
import com.clarifi.phoenix.ashes.data.SecurityMasterCache;
import com.clarifi.phoenix.ashes.data.TimeSeriesDataCache;
import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteCache;
import org.apache.ignite.IgniteException;
import org.apache.ignite.Ignition;
import org.apache.ignite.configuration.IgniteConfiguration;

/**
 * A class to load some sample data into Ignite caches
 */
public class LoadSampleSMData {

  public static void main(String[] args) throws IgniteException
  {
    IgniteConfiguration cfg = Common.igniteClientConfiguration();

    // Starting the node
    Ignite ignite = Ignition.start(cfg);

    IgniteCache<Integer, IssueData> smCache = ignite.getOrCreateCache(SecurityMasterCache.configuration());

    // Create an IgniteCache and put some values in it.
    int numIssues = 5000;
    loadSMValues(smCache, numIssues);

    System.out.println(">> Created the cache '" + smCache.getName() + "' and added " + numIssues + " values.");

    // Disconnect from the cluster.
    ignite.close();
  }

  private static void loadSMValues(IgniteCache<Integer, IssueData> smCache, int numValues)
  {

    for (int i = 0; i < numValues; ++i) {
      int issueId = TimeSeriesDataCache.generateIssueId(i);
      IssueData issue = IssueData.fill(issueId);

      smCache.put(i, issue);
      System.out.println(">> Inserted issue " + issueId);
    }

  }

}
