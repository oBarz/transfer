package com.clarifi.phoenix.ashes.node;

import com.clarifi.concurrent.PoolSize;
import com.clarifi.concurrent.batch.BatchingThreadPool;
import org.apache.ignite.Ignite;
import org.apache.ignite.resources.IgniteInstanceResource;
import org.apache.ignite.resources.ServiceContextResource;
import org.apache.ignite.services.Service;
import org.apache.ignite.services.ServiceContext;

import java.util.concurrent.*;

public class SimpleExecutorImpl implements Service, SimpleExecutorService {
    private BatchingThreadPool pool;
    private BlockingQueue<Runnable> queue;
    private ExecutorService executor;

    @IgniteInstanceResource
    private Ignite ignite;

    @ServiceContextResource
    private ServiceContext ctx;

    public SimpleExecutorImpl() {
    }

    @Override
    public void init() throws Exception {
        queue = new ArrayBlockingQueue<>(32);
        executor = new ThreadPoolExecutor(
                2, 4, 5L, TimeUnit.MINUTES, queue);

        executor.submit(new Runnable() {
            @Override
            public void run() {
                System.out.printf("{Thread:%s} Hello from JDK's tread pool\n", Thread.currentThread().getName());
            }
        });

        pool = BatchingThreadPool.builder("AppThreadPool", PoolSize.cached(2, 16)).build();
        pool.submit(new Runnable() {
            @Override
            public void run() {
                System.out.printf("{Thread:%s} Hello from Glav's tread pool\n", Thread.currentThread().getName());
            }
        });

        System.out.printf("Distributed service '%s' was initialized\n", ctx.name());
    }

    @Override
    public void cancel() {
        pool.shutdownNow();

        queue.clear();
        executor.shutdownNow();

        System.out.printf("Distributed service '%s' terminated\n", ctx.name());
    }

    @Override
    public void execute() throws Exception {
        System.out.printf("Executing distributed service '%s'\n", ctx.name());
    }

    @Override
    public ExecutorService getExecutor() {
        return executor;
    }

    @Override
    public void submitToJDK(final Runnable task) {
        executor.submit(task);
    }

    @Override
    public <V> Future<V> submitToJDK(final Callable<V> callable) {
        return executor.submit(callable);
    }

    @Override
    public void submitToTL(final Runnable task) {
        pool.submit(task);
    }

    @Override
    public <V> Future<V> submitToTL(final Callable<V> callable) {
        return pool.submit(callable);
    }

    @Override
    public BatchingThreadPool getTLPool() {
        return pool;
    }
}
