package com.clarifi.phoenix.ashes.task;

import com.clarifi.phoenix.ashes.common.Common;
import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteException;
import org.apache.ignite.Ignition;
import org.apache.ignite.configuration.IgniteConfiguration;
import org.apache.ignite.lang.IgniteRunnable;
import org.apache.ignite.resources.IgniteInstanceResource;

import java.util.*;

/**
 * A computation tasks that prints out a node ID and some details about its OS and JRE.
 * Plus, the code shows how to access data stored in a cache from the computation task.
 */
class OOMETask implements IgniteRunnable {
  private final UUID _targetId;

  @IgniteInstanceResource
  Ignite ignite;

  public OOMETask(UUID targetNodeId) {
    _targetId = targetNodeId;
  }

  @Override
  public void run() {
    System.out.println(">> Executing the Out of Memory Task");

    UUID nodeId = ignite.cluster().localNode().id();

    System.out.println("\tNode ID: " + nodeId);

    if (!_targetId.equals(nodeId)) {
      System.out.println("\tTarget node ID does not match, exiting");
      return;
    }

    System.out.println("\tAllocating 4GB memory in 4MB chunks");

    List<int[]> memoryGrabList = new ArrayList<>(1024);
    for (int i = 0; i < 1024; ++i) {
      int[] chunk = new int[1024 * 1024]; // 4 MB chunk
      memoryGrabList.add(chunk);

    }
  }

  public static void main(String[] args) throws IgniteException {
    IgniteConfiguration cfg = Common.igniteClientConfiguration();

    // Starting the node
    Ignite ignite = Ignition.start(cfg);

    try {
      UUID targetNodeId = UUID.fromString("e8c3e2f3-28c1-4dc8-a4cd-49a6b98b8412");

      ignite.compute(ignite.cluster().forServers()).broadcast(new OOMETask(targetNodeId));
      System.out.println(">> Compute task is executed, check for output on the server nodes.");
    }
    finally {
      // Disconnect from the cluster.
      ignite.close();
    }
  }

}
