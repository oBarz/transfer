package com.clarifi.phoenix.ashes.server;

import com.clarifi.phoenix.ashes.common.IssueDataSlicedByDataItem;
import com.clarifi.phoenix.ashes.common.PhoenixDate;
import com.clarifi.phoenix.ashes.common.PhoenixDateRange;
import com.clarifi.phoenix.ashes.data.TimeSeriesDataKey;
import org.apache.ignite.Ignite;
import org.apache.ignite.lang.IgniteCallable;
import org.apache.ignite.resources.IgniteInstanceResource;

import javax.cache.Cache;
import java.util.List;

public class GetTimeSeriesSlice implements IgniteCallable<IssueDataSlicedByDataItem> {
    private final int issueId;
    private final int dataItemId;
    private final PhoenixDate date;

    @IgniteInstanceResource
    private Ignite ignite;

    public GetTimeSeriesSlice(final int issueId, final int dataItemId, final PhoenixDate date) {
        this.issueId = issueId;
        this.dataItemId = dataItemId;
        this.date = date;
    }

    @Override
    public IssueDataSlicedByDataItem call() {
        final TimeSeriesDataKey key = new TimeSeriesDataKey(issueId, dataItemId);

        final Cache<TimeSeriesDataKey, List<IssueDataSlicedByDataItem>> cache = ignite.cache("TIME_SERIES");
        final List<IssueDataSlicedByDataItem> list = cache.get(key);
        if (list == null || list.isEmpty()) {
            return null;
        }

        for (final IssueDataSlicedByDataItem item : list) {
            final PhoenixDateRange range = PhoenixDateRange.fromPackedValue(item.getDateRange());

            if (range.contains(date)) {
                char start = range.getStart().getPackedValue();
                int index = date.getPackedValue() - start;

                final double[] data = item.getValues();

                System.out.printf(
                    "{Thread:%s} Value for issue=%d, dataItem=%d and date=%s is %.2f\n",
                    Thread.currentThread().getName(),
                    key.issueId,
                    key.dataItemId,
                    date,
                    data[index]
                );

                return item;
            }
        }

        return null;
    }
}
