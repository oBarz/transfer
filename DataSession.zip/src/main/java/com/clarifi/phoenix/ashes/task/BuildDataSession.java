package com.clarifi.phoenix.ashes.task;

import com.clarifi.phoenix.ashes.common.*;
import com.clarifi.phoenix.ashes.data.TimeSeriesDataKey;
import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteCache;
import org.apache.ignite.cache.CacheMode;
import org.apache.ignite.cache.CachePeekMode;
import org.apache.ignite.cache.CacheRebalanceMode;
import org.apache.ignite.cache.PartitionLossPolicy;
import org.apache.ignite.configuration.CacheConfiguration;
import org.apache.ignite.lang.IgniteCallable;
import org.apache.ignite.resources.IgniteInstanceResource;

import javax.cache.Cache;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.UUID;

public class BuildDataSession implements IgniteCallable<Boolean> {
    private final PackedDataSession session;
    private final String cacheName;

    @IgniteInstanceResource
    Ignite ignite;

    public BuildDataSession(final PackedDataSession session, final String cacheName) {
        this.session = session;
        this.cacheName = cacheName;
    }

    @Override
    public Boolean call() {
        final IgniteCache<UUID, PackedDataSession> userDataSessionCache = ignite.cache(cacheName);

        // todo: use the threading library to compute this in parallel
        final CacheConfiguration<TimeSeriesDataKey, List<IssueDataSlicedByDataItem>> cfgTimeSeries = getTimeSeriesConfig();

        int hits = 0;
        int misses = 0;

        final int[] issues = session.getIssues();
        for (final int issueId: issues) {
            final IssueDataSlicedByDataItem.Builder builder = new IssueDataSlicedByDataItem.Builder();
            builder.setIssueId(issueId);
            builder.setRange(session.getRange());

            for (final int dataItemId: session.getDataItems()) {
                builder.setDataItemId(dataItemId);

                PhoenixDate date = session.getRange().getStart();
                while (session.getRange().contains(date)) {
                    builder.setValue(date, (double) issueId / (double) dataItemId);
                    date = date.plusDays(1);
                }

                final IssueDataSlicedByDataItem slice = builder.build();

                final Cache<TimeSeriesDataKey, List<IssueDataSlicedByDataItem>> cache = ignite.getOrCreateCache(cfgTimeSeries);
                final TimeSeriesDataKey key = new TimeSeriesDataKey(slice.getIssueId(), slice.getDataItemId());

                final List<IssueDataSlicedByDataItem> list = cache.get(key);
                if (list == null || list.isEmpty()) {
                    final List<IssueDataSlicedByDataItem> newList = new ArrayList<>();
                    newList.add(slice);

                    cache.put(key, newList);
                    misses++;
                } else {
                    boolean found = false;
                    for (final IssueDataSlicedByDataItem item: list) {
                        if (item.equals(slice)) {
                            found = true;
                            hits++;

                            break;
                        }
                    }

                    if (!found) {
                        list.add(slice);
                        cache.replace(key, list);
                    }
                }
            }
        }

        // todo: intentionally iterating twice to lengthen the build process for testing
        final CacheConfiguration<CrossSectionalDataKey, List<IssueDataSlicedByDate>> cfgCrossSectional = getCrossSectionalConfig();

        for (final int issueId: issues) {
            final IssueDataSlicedByDate.Builder builder = new IssueDataSlicedByDate.Builder();
            builder.setIssueId(issueId);

            PhoenixDate date = session.getRange().getStart();
            while (session.getRange().contains(date)) {
                builder.setDate(date);

                for (final int dataItemId: session.getDataItems()) {
                    final int index = builder.addDataItem(dataItemId);
                    builder.setValue(index, (double) issueId / (double) dataItemId);
                }

                final IssueDataSlicedByDate slice = builder.build();

                final Cache<CrossSectionalDataKey, List<IssueDataSlicedByDate>> cache = ignite.getOrCreateCache(cfgCrossSectional);
                final CrossSectionalDataKey key = new CrossSectionalDataKey(issueId, date.getPackedValue());

                final List<IssueDataSlicedByDate> list = cache.get(key);
                if (list == null || list.isEmpty()) {
                    final List<IssueDataSlicedByDate> newList = new LinkedList<>();
                    newList.add(slice);

                    cache.put(key, newList);
                    misses++;
                } else {
                    boolean found = false;

                    for (final IssueDataSlicedByDate item: list) {
                        if (item.equals(slice)) {
                            found = true;
                            hits++;

                            break;
                        }
                    }

                    if (!found) {
                        list.add(slice);
                        cache.replace(key, list);
                    }
                }

                date = date.plusDays(1);
            }
        }

        session.setStatus(DataSession.Status.Available);
//        task.setProgress(1d);

        System.out.printf("Session %s created: Cache hits %d, misses %d\n", session.getId(), hits, misses);
        System.out.printf("User %s has %d data sessions\n", session.getUserId(), userDataSessionCache.size());
        System.out.printf("TimeSeries cache size: %d\n", ignite.cache(cfgTimeSeries.getName()).size(CachePeekMode.ALL));
        System.out.printf("CrossSectional cache size: %d\n", ignite.cache(cfgCrossSectional.getName()).size(CachePeekMode.ALL));

        return Boolean.TRUE;
    }

    private static CacheConfiguration<TimeSeriesDataKey, List<IssueDataSlicedByDataItem>> getTimeSeriesConfig() {
        final CacheConfiguration<TimeSeriesDataKey, List<IssueDataSlicedByDataItem>> config = new CacheConfiguration<>();
        config.setName("TIME_SERIES");
        config.setCacheMode(CacheMode.PARTITIONED);
        config.setBackups(2);
        config.setRebalanceMode(CacheRebalanceMode.SYNC);
        config.setPartitionLossPolicy(PartitionLossPolicy.READ_ONLY_SAFE);

        return config;
    }

    private static CacheConfiguration<CrossSectionalDataKey, List<IssueDataSlicedByDate>> getCrossSectionalConfig() {
        final CacheConfiguration<CrossSectionalDataKey, List<IssueDataSlicedByDate>> config = new CacheConfiguration<>();
        config.setName("CROSS_SECTIONAL");
        config.setCacheMode(CacheMode.PARTITIONED);
        config.setBackups(2);
        config.setRebalanceMode(CacheRebalanceMode.SYNC);
        config.setPartitionLossPolicy(PartitionLossPolicy.READ_ONLY_SAFE);

        return config;
    }
}
