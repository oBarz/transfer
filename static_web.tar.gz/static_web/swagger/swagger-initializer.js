window.onload = function() {
  //<editor-fold desc="Changeable Configuration Block">

  // Define the base URL of your Swagger API endpoint
  var baseUrl = "http://localhost:8081/api2"; // Change this to match your API base URL

  // Initialize Swagger UI with your custom configuration
  window.ui = SwaggerUIBundle({
    url: "openapi.json", // Point to your Swagger JSON file in the same directory as index.html
    dom_id: '#swagger-ui',
    deepLinking: true,
    presets: [
      SwaggerUIBundle.presets.apis,
      SwaggerUIStandalonePreset
    ],
    plugins: [
      SwaggerUIBundle.plugins.DownloadUrl
    ],
    layout: "StandaloneLayout"
  });

  //</editor-fold>
};

